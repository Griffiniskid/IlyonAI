"""
Crypto agent for the BNB Chain ecosystem.

Tools
-----
get_native_balance — native BNB balance on BNB Smart Chain via public RPC
simulate_swap      — token swap quote via 1inch Aggregation Protocol v6
get_token_price    — real-time USD price via Binance REST, CoinGecko fallback
build_swap_tx      — full swap transaction via 1inch (EVM) or Jupiter (Solana)
                     with platform referral fee; returns ready-to-sign JSON

Agent type: ZERO_SHOT_REACT_DESCRIPTION with ConversationBufferMemory
"""

import concurrent.futures
import json
import logging
import os
import re
import time
from typing import Any, Final, Optional

import httpx
import requests as _requests
from dotenv import dotenv_values
from langchain.agents import AgentExecutor, AgentType, initialize_agent
from langchain.memory import ConversationBufferWindowMemory
from langchain.tools import Tool
from langchain_openai import ChatOpenAI
from web3 import Web3

from app.core.config import settings

logger = logging.getLogger(__name__)

def _load_moralis_api_key(env_path: Optional[Any] = None) -> str:
    fallback = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJub25jZSI6IjE0NDg5ZDk4LWQ0ZDctNGMxYi04ODVkLWQ2NDIzOTA2MWExOSIsIm9yZ0lkIjoiNDA5OTI1IiwidXNlcklkIjoiNDIxMDk1IiwidHlwZUlkIjoiZjFiMDE5OWMtNGFmZi00ZmMxLTg3YzQtZDE4NGI5Y2JmMDE4IiwidHlwZSI6IlBST0pFQ1QiLCJpYXQiOjE3MjkwNjU4MDAsImV4cCI6NDg4NDgyNTgwMH0.gg6GCQiPoApjJhE1TFHaaCxKMY9Qn-e3BTVb9ILPfU0"
    if os.environ.get("MORALIS_API_KEY"):
        return os.environ["MORALIS_API_KEY"]

    resolved_env = env_path
    if resolved_env is None:
        resolved_env = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), ".env")

    try:
        env_values = dotenv_values(str(resolved_env))
        env_key = env_values.get("MORALIS_API_KEY")
        if env_key:
            return str(env_key)
    except Exception:
        pass

    return fallback


MORALIS_API_KEY: str = _load_moralis_api_key()

# Moralis chain IDs for ERC-20 token scanning (chains supported by Moralis)
_MORALIS_CHAINS: Final[dict[str, str]] = {
    "Ethereum": "eth",
    "BNB Chain": "bsc",
    "Polygon": "polygon",
    "Avalanche": "avalanche",
    "Arbitrum": "arbitrum",
    "Optimism": "optimism",
    "Base": "base",
}

# ---------------------------------------------------------------------------
# Chain constants
# ---------------------------------------------------------------------------

# Fallback RPC URLs when not present in settings.rpc_urls
_RPC_FALLBACK: Final[dict[int, str]] = {
    1:   "https://rpc.ankr.com/eth",
    56:  "https://rpc.ankr.com/bsc",
    137: "https://rpc.ankr.com/polygon",
}

# Chain IDs supported by 1inch Aggregation Protocol v6
_ONEINCH_SUPPORTED: Final = frozenset({1, 56, 137, 42161, 10, 8453, 43114})

# ---------------------------------------------------------------------------
# Chain metadata — name, native symbol, native decimals
# ---------------------------------------------------------------------------

_CHAIN_META: Final[dict[int, dict[str, str]]] = {
    1:      {"name": "Ethereum",          "native": "ETH",  "native_name": "Ether"},
    56:     {"name": "BNB Smart Chain",   "native": "BNB",  "native_name": "BNB"},
    137:    {"name": "Polygon",           "native": "MATIC","native_name": "MATIC"},
    8453:   {"name": "Base",              "native": "ETH",  "native_name": "Ether"},
    10:     {"name": "Optimism",          "native": "ETH",  "native_name": "Ether"},
    43114:  {"name": "Avalanche",         "native": "AVAX", "native_name": "AVAX"},
    42161:  {"name": "Arbitrum One",      "native": "ETH",  "native_name": "Ether"},
    324:    {"name": "zkSync Era",        "native": "ETH",  "native_name": "Ether"},
    59144:  {"name": "Linea",             "native": "ETH",  "native_name": "Ether"},
    534352: {"name": "Scroll",            "native": "ETH",  "native_name": "Ether"},
    5000:   {"name": "Mantle",            "native": "MNT",  "native_name": "MNT"},
    250:    {"name": "Fantom",            "native": "FTM",  "native_name": "FTM"},
    100:    {"name": "Gnosis",            "native": "xDAI", "native_name": "xDAI"},
    42220:  {"name": "Celo",              "native": "CELO", "native_name": "CELO"},
    25:     {"name": "Cronos",            "native": "CRO",  "native_name": "CRO"},
}

# Maps a unique native symbol → canonical chain_id (for auto-detecting chain from token)
_NATIVE_SYMBOL_TO_CHAIN: Final[dict[str, int]] = {
    "bnb": 56, "matic": 137, "avax": 43114, "mnt": 5000,
    "ftm": 250, "xdai": 100, "celo": 42220, "cro": 25,
}

def _chain_name(chain_id: int) -> str:
    return _CHAIN_META.get(chain_id, {}).get("name", f"Chain {chain_id}")

def _native_symbol(chain_id: int) -> str:
    return _CHAIN_META.get(chain_id, {}).get("native", "ETH")

# ---------------------------------------------------------------------------
# Multi-chain token registry — indexed by chain_id
# Allows build_transfer_tx to resolve addresses without any external calls.
# ---------------------------------------------------------------------------

# Ethereum Mainnet — chain 1
_TOKENS_ETH: Final[dict[str, dict[str, Any]]] = {
    "usdt": {"address": "0xdAC17F958D2ee523a2206206994597C13D831ec7", "decimals": 6},
    "usdc": {"address": "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48", "decimals": 6},
    "dai":  {"address": "0x6B175474E89094C44Da98b954EedeAC495271d0F", "decimals": 18},
    "wbtc": {"address": "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599", "decimals": 8},
    "weth": {"address": "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2", "decimals": 18},
    "link": {"address": "0x514910771AF9Ca656af840dff83E8264EcF986CA", "decimals": 18},
    "uni":  {"address": "0x1f9840a85d5aF5bf1D1762F925BDADdC4201F984", "decimals": 18},
    "aave": {"address": "0x7Fc66500c84A76Ad7e9c93437bFc5Ac33E2DDaE9", "decimals": 18},
    "shib": {"address": "0x95aD61b0a150d79219dCF64E1E6Cc01f0B64C4cE", "decimals": 18},
}

# BNB Smart Chain (BSC) — chain 56
_TOKENS_BSC: Final[dict[str, dict[str, Any]]] = {
    "usdt":  {"address": "0x55d398326f99059fF775485246999027B3197955", "decimals": 18},
    "usdc":  {"address": "0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d", "decimals": 18},
    "busd":  {"address": "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56", "decimals": 18},
    "dai":   {"address": "0x1AF3F329e8BE154074D8769D1FFa4eE058B1DBc3", "decimals": 18},
    "tusd":  {"address": "0x14016E85a25aeb13065688cAFB43044C2ef86784", "decimals": 18},
    "cake":  {"address": "0x0E09FaBB73Bd3Ade0a17ECC321fD13a19e81cE82", "decimals": 18},
    "wbnb":  {"address": "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c", "decimals": 18},
    "xvs":   {"address": "0xcF6BB5389c92Bdda8a3747Ddb454cB7a64626C63", "decimals": 18},
    "bake":  {"address": "0xE02dF9e3e622DeBdD69fb838bB799E3F168902c5", "decimals": 18},
    "eth":   {"address": "0x2170Ed0880ac9A755fd29B2688956BD959F933F8", "decimals": 18},
    "btcb":  {"address": "0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c", "decimals": 18},
    "wbtc":  {"address": "0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c", "decimals": 18},
    "ada":   {"address": "0x3EE2200Efb3400fAbB9AacF31297cBdD1d435D47", "decimals": 18},
    "doge":  {"address": "0xbA2aE424d960c26247Dd6c32edC70B295c744C43", "decimals": 8},
    "dot":   {"address": "0x7083609fCE4d1d8Dc0C979AAb8c869Ea2C873402", "decimals": 18},
    "matic": {"address": "0xCC42724C6683B7E57334c4E856f4c9965ED682bD", "decimals": 18},
    "link":  {"address": "0xF8A0BF9cF54Bb92F17374d9e9A321E6a111a51bD", "decimals": 18},
    "uni":   {"address": "0xBf5140A22578168FD562DCcF235E5D43A02ce9B1", "decimals": 18},
    "aave":  {"address": "0xfb6115445Bff7b52FeB98650C87f44907E58f802", "decimals": 18},
    "trx":   {"address": "0x85EAC5Ac2F758618dFa09bDbe0cf174e7d574D5B", "decimals": 6},
    "xrp":   {"address": "0x1D2F0da169ceB9fC7B3144628dB156f3F6c60dBE", "decimals": 18},
    "ltc":   {"address": "0x4338665CBB7B2485A8855A139b75D5e34AB0DB94", "decimals": 18},
    "fdusd": {"address": "0xc5f0f7b66764F6ec8C8Dff7BA683102295E16409", "decimals": 18},
}

# Polygon — chain 137
_TOKENS_POLYGON: Final[dict[str, dict[str, Any]]] = {
    "usdc":  {"address": "0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359", "decimals": 6},
    "usdt":  {"address": "0xc2132D05D31c914a87C6611C10748AEb04B58e8F", "decimals": 6},
    "dai":   {"address": "0x8f3Cf7ad23Cd3CaDbD9735AFf958023239c6A063", "decimals": 18},
    "wbtc":  {"address": "0x1BFD67037B42Cf73acF2047067bd4F2C47D9BfD6", "decimals": 8},
    "weth":  {"address": "0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619", "decimals": 18},
    "link":  {"address": "0x53E0bca35eC356BD5ddDFebbD1Fc0fD03FaBad39", "decimals": 18},
    "aave":  {"address": "0xD6DF932A45C0f255f85145f286eA0b292B21C90B", "decimals": 18},
    "wmatic":{"address": "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270", "decimals": 18},
}

# Base — chain 8453
_TOKENS_BASE: Final[dict[str, dict[str, Any]]] = {
    "usdc":  {"address": "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913", "decimals": 6},
    "dai":   {"address": "0x50c5725949A6F0c72E6C4a641F24049A917DB0Cb", "decimals": 18},
    "weth":  {"address": "0x4200000000000000000000000000000000000006", "decimals": 18},
}

# Optimism — chain 10
_TOKENS_OP: Final[dict[str, dict[str, Any]]] = {
    "usdc":  {"address": "0x0b2C639c533813f4Aa9D7837CAf62653d097Ff85", "decimals": 6},
    "usdt":  {"address": "0x94b008aA00579c1307B0EF2c499aD98a8ce58e58", "decimals": 6},
    "dai":   {"address": "0xDA10009cBd5D07dd0CeCc66161FC93D7c9000da1", "decimals": 18},
    "weth":  {"address": "0x4200000000000000000000000000000000000006", "decimals": 18},
    "op":    {"address": "0x4200000000000000000000000000000000000042", "decimals": 18},
}

# Arbitrum One — chain 42161
_TOKENS_ARB: Final[dict[str, dict[str, Any]]] = {
    "usdc":  {"address": "0xaf88d065e77c8cC2239327C5EDb3A432268e5831", "decimals": 6},
    "usdt":  {"address": "0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9", "decimals": 6},
    "dai":   {"address": "0xDA10009cBd5D07dd0CeCc66161FC93D7c9000da1", "decimals": 18},
    "wbtc":  {"address": "0x2f2a2543B76A4166549F7aaB2e75Bef0aefC5B0f", "decimals": 8},
    "weth":  {"address": "0x82aF49447D8a07e3bd95BD0d56f35241523fBab1", "decimals": 18},
    "arb":   {"address": "0x912CE59144191C1204E64559FE8253a0e49E6548", "decimals": 18},
}

# Chain-indexed registry
TOKENS_BY_CHAIN: Final[dict[int, dict[str, dict[str, Any]]]] = {
    1:     _TOKENS_ETH,
    56:    _TOKENS_BSC,
    137:   _TOKENS_POLYGON,
    8453:  _TOKENS_BASE,
    10:    _TOKENS_OP,
    42161: _TOKENS_ARB,
}

# Backwards-compatible alias for code that doesn't pass chain_id
POPULAR_TOKENS: Final[dict[str, dict[str, Any]]] = _TOKENS_BSC

# ---------------------------------------------------------------------------
# Session memory store
# NOTE: process-scoped dict — replace with Redis + TTL in production
# ---------------------------------------------------------------------------

_session_memory: dict[str, ConversationBufferWindowMemory] = {}


def _get_or_create_memory(session_id: str) -> ConversationBufferWindowMemory:
    if session_id not in _session_memory:
        # k=6: keeps last 6 exchanges (12 messages) — enough context, minimal tokens
        _session_memory[session_id] = ConversationBufferWindowMemory(
            memory_key="chat_history",
            return_messages=True,
            k=6,
        )
    return _session_memory[session_id]


def clear_session_memory(session_id: str) -> None:
    """Explicitly drop a session's memory (e.g. on logout)."""
    _session_memory.pop(session_id, None)


# ---------------------------------------------------------------------------
# Step 1 — LLM
# Priority: OpenRouter → Groq → OpenAI
# ---------------------------------------------------------------------------

_OPENROUTER_MODELS = [
    "openai/gpt-4o-mini",
    "anthropic/claude-3-5-haiku",
    "google/gemma-3-27b-it:free",
    "meta-llama/llama-3.3-70b-instruct:free",
]


def _build_llm(openrouter_model: Optional[str] = None):
    # "__openai__" sentinel: use OpenAI API directly
    if openrouter_model == "__openai__":
        logger.info("Using OpenAI LLM (gpt-4o-mini)")
        return ChatOpenAI(
            model="gpt-4o-mini",
            temperature=0,
            request_timeout=45,
            openai_api_key=settings.api_keys.get("openai", ""),
        )

    # "__groq__" sentinel: skip OpenRouter and go straight to Groq
    if openrouter_model == "__groq__":
        groq_key = settings.api_keys.get("groq", "")
        from langchain_groq import ChatGroq
        logger.info("Using Groq LLM (llama-3.3-70b-versatile)")
        return ChatGroq(
            model="llama-3.3-70b-versatile",
            temperature=0,
            groq_api_key=groq_key,
            request_timeout=45,
        )

    # Default: OpenRouter with the specified model
    openrouter_key = settings.api_keys.get("openrouter", "")
    model = openrouter_model or _OPENROUTER_MODELS[0]
    logger.info("Using OpenRouter LLM (%s)", model)
    return ChatOpenAI(
        model=model,
        temperature=0,
        openai_api_key=openrouter_key,
        openai_api_base="https://openrouter.ai/api/v1",
        request_timeout=45,
        default_headers={
            "HTTP-Referer": "https://agent-platform.local",
            "X-Title": "Agent Platform",
        },
    )


# ---------------------------------------------------------------------------
# Step 3 — Tool implementations
# ---------------------------------------------------------------------------

_BALANCE_CHAINS: Final[list[dict]] = [
    {
        "name": "Ethereum",
        "rpcs": ["https://eth.llamarpc.com", "https://ethereum.publicnode.com"],
        "native": "ETH",
        "tokens": [
            ("USDC", "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48", 6),
            ("USDT", "0xdAC17F958D2ee523a2206206994597C13D831ec7", 6),
        ],
    },
    {
        "name": "BNB Chain",
        "rpcs": ["https://bsc-dataseed.binance.org", "https://bsc.publicnode.com"],
        "native": "BNB",
        "tokens": [
            ("USDC", "0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d", 18),
            ("USDT", "0x55d398326f99059fF775485246999027B3197955", 18),
            ("CAKE", "0x0E09FaBB73Bd3Ade0a17ECC321fD13a19e81cE82", 18),
            ("ABRA", "0x341c05c0E9b33C0E38d64de76516b2Ce970bB3BE", 18),
        ],
    },
    {
        "name": "Polygon",
        "rpcs": ["https://polygon-bor-rpc.publicnode.com", "https://1rpc.io/matic"],
        "native": "MATIC",
        "tokens": [
            ("USDC", "0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359", 6),
            ("USDT", "0xc2132D05D31c914a87C6611C10748AEb04B58e8F", 6),
        ],
    },
    {
        "name": "Arbitrum",
        "rpcs": ["https://arb1.arbitrum.io/rpc", "https://arbitrum.publicnode.com"],
        "native": "ETH",
        "tokens": [
            ("USDC", "0xaf88d065e77c8cC2239327C5EDb3A432268e5831", 6),
            ("USDT", "0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9", 6),
        ],
    },
    {
        "name": "Optimism",
        "rpcs": ["https://mainnet.optimism.io", "https://optimism.publicnode.com"],
        "native": "ETH",
        "tokens": [
            ("USDC", "0x0b2C639c533813f4Aa9D7837CAf62653d097Ff85", 6),
            ("USDT", "0x94b008aA00579c1307B0EF2c499aD98a8ce58e58", 6),
        ],
    },
    {
        "name": "Base",
        "rpcs": ["https://mainnet.base.org", "https://base.llamarpc.com"],
        "native": "ETH",
        "tokens": [
            ("USDC", "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913", 6),
            ("USDT", "0xfde4C96c8593536E31F229EA8f37b2ADa2699bb2", 6),
        ],
    },
    {
        "name": "Avalanche",
        "rpcs": ["https://api.avax.network/ext/bc/C/rpc", "https://avalanche-c-chain-rpc.publicnode.com"],
        "native": "AVAX",
        "tokens": [
            ("USDC", "0xB97EF9Ef8734C71904D8002F8b6Bc66Dd9c48a6E", 6),
            ("USDT", "0x9702230A8Ea53601f5cD2dc00fDBc13d4dF4A8c7", 6),
        ],
    },
    {
        "name": "zkSync Era",
        "rpcs": ["https://mainnet.era.zksync.io"],
        "native": "ETH",
        "tokens": [
            ("USDC", "0x1d17CBcF0D6D143135aE902365D2E5e2A16538D4", 6),
            ("USDT", "0x493257fD37EFE3a9E3a304E4C8c71706d1eE41f7", 6),
        ],
    },
    {
        "name": "Linea",
        "rpcs": ["https://rpc.linea.build", "https://linea.publicnode.com"],
        "native": "ETH",
        "tokens": [
            ("USDC", "0x176211869cA2b568f2A7D4EE941E073a821EE1ff", 6),
            ("USDT", "0xA219439258ca9da29E9Cc4cE5596924745e12B93", 6),
        ],
    },
    {
        "name": "Scroll",
        "rpcs": ["https://rpc.scroll.io", "https://scroll.publicnode.com"],
        "native": "ETH",
        "tokens": [
            ("USDC", "0x06eFdBFf2a14a7c8E15944D1F4A48F9F95F663A4", 6),
            ("USDT", "0xf55BEC9cafDbE8730f096Aa55dad6D22d44099Df", 6),
        ],
    },
    {
        "name": "Mantle",
        "rpcs": ["https://rpc.mantle.xyz", "https://mantle.publicnode.com"],
        "native": "MNT",
        "tokens": [
            ("USDC", "0x09Bc4E0D864854c6aFB6eB9A9cdF58aC190D0dF9", 6),
            ("USDT", "0x201EBa5CC46D216Ce6DC03F6a759e8E766e956aE", 6),
        ],
    },
    {
        "name": "Fantom",
        "rpcs": ["https://rpcapi.fantom.network", "https://fantom-mainnet.public.blastapi.io"],
        "native": "FTM",
        "tokens": [
            ("USDC", "0x04068DA6C83AFCFA0e13ba15A6696662335D5B75", 6),
            ("USDT", "0x049d68029688eAbF473097a2fC38ef61633A3C7A", 6),
        ],
    },
    {
        "name": "Gnosis",
        "rpcs": ["https://rpc.gnosischain.com", "https://gnosis.publicnode.com"],
        "native": "xDAI",
        "tokens": [
            ("USDC", "0xDDAfbb505ad214D7b80b1f830fcCc89B60fb7A83", 6),
            ("USDT", "0x4ECaBa5870353805a9F068101A40E0f32ed605C6", 6),
        ],
    },
    {
        "name": "Celo",
        "rpcs": ["https://forno.celo.org", "https://celo.publicnode.com"],
        "native": "CELO",
        "tokens": [
            ("USDC", "0xcebA9300f2b948710d2653dD7B07f33A8B32118C", 6),
            ("USDT", "0x48065fbBE25f71C9282ddf5e1cD6D6A887483D5e", 6),
        ],
    },
    {
        "name": "Cronos",
        "rpcs": ["https://evm.cronos.org", "https://cronos.publicnode.com"],
        "native": "CRO",
        "tokens": [
            ("USDC", "0xc21223249CA28397B4B6541dfFaEcC539BfF0c59", 6),
            ("USDT", "0x66e428c3f67a68878562e79A0234c1F83c208770", 6),
        ],
    },
    {
        "name": "Solana",
        "type": "solana",
        "rpcs": ["https://api.mainnet-beta.solana.com", "https://solana-rpc.publicnode.com", "https://rpc.ankr.com/solana"],
        "native": "SOL",
        "tokens": [
            ("USDC", "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v", 6),
            ("USDT", "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB", 6),
        ],
    },
]


_CHAIN_ALIASES: dict[str, str] = {
    "eth": "Ethereum", "ethereum": "Ethereum",
    "bnb": "BNB Chain", "bsc": "BNB Chain", "binance": "BNB Chain", "bnbchain": "BNB Chain",
    "polygon": "Polygon", "matic": "Polygon",
    "arbitrum": "Arbitrum", "arb": "Arbitrum",
    "optimism": "Optimism", "op": "Optimism",
    "base": "Base",
    "avalanche": "Avalanche", "avax": "Avalanche",
    "zksync": "zkSync Era", "zksyncera": "zkSync Era",
    "linea": "Linea",
    "scroll": "Scroll",
    "mantle": "Mantle", "mnt": "Mantle",
    "fantom": "Fantom", "ftm": "Fantom",
    "gnosis": "Gnosis", "xdai": "Gnosis",
    "celo": "Celo",
    "cronos": "Cronos", "cro": "Cronos",
    "solana": "Solana", "sol": "Solana",
}

_SOL_RPCS_AGENT = [
    "https://api.mainnet-beta.solana.com",
    "https://solana-rpc.publicnode.com",
    "https://rpc.ankr.com/solana",
]
_SOL_SPL_TOKENS = [
    ("USDC", "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"),
    ("USDT", "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB"),
]


_BINANCE_PAIRS: Final[dict[str, str]] = {
    "BNB": "BNBUSDT", "ETH": "ETHUSDT", "SOL": "SOLUSDT",
    "AVAX": "AVAXUSDT", "MATIC": "MATICUSDT", "FTM": "FTMUSDT",
    "CRO": "CROUSDT", "MNT": "MNTUSDT", "xDAI": "DAIUSDT",
    "CELO": "CELOUSDT",
}


def _get_price_usd(symbol: str) -> float:
    """Fetch USD price from Binance REST; returns 0.0 on any error."""
    pair = _BINANCE_PAIRS.get(symbol)
    if not pair:
        return 0.0
    try:
        r = _requests.get(
            f"https://api.binance.com/api/v3/ticker/price?symbol={pair}",
            timeout=3,
        )
        if r.status_code == 200:
            return float(r.json().get("price", 0))
    except Exception:
        pass
    return 0.0


def _passes_balance_filter(token: dict, trusted_usd: float, ui_bal: float) -> bool:
    # 1. Filter out obvious spam if the API (e.g., Moralis) flags it
    is_spam = token.get("possible_spam", False)

    # 2. A token passes the filter if:
    # - It has real fiat value (>= $0.01), which saves micro-fractions of WBTC/WETH
    # OR
    # - It has a substantial balance amount (>= 0.00000001 for Satoshis/Wei or > 1 for meme coins)
    return not is_spam and (trusted_usd >= 0.01 or ui_bal >= 0.00000001)


def _scan_single_address(raw_addr: str, target_chain: str) -> list[dict]:
    """Scan one address and return a list of chain balance dicts."""
    is_solana_addr = not raw_addr.startswith("0x") and len(raw_addr) >= 32

    # ── Solana ───────────────────────────────────────────────────────────────
    if is_solana_addr:
        sol_native = 0.0
        sol_tokens: list[dict] = []
        sol_seen: set[str] = {"SOL"}  # pre-seed native
        print(f"[SOL] Scanning wallet: {raw_addr}")
        try:
            rpc_url = "https://api.mainnet-beta.solana.com"
            headers = {"Content-Type": "application/json"}

            # 1. Native SOL
            sol_resp = _requests.post(rpc_url, json={
                "jsonrpc": "2.0", "id": 1, "method": "getBalance", "params": [raw_addr]
            }, headers=headers, timeout=10)
            print(f"[SOL] SOL DATA: {sol_resp.text}")
            sol_bal = (sol_resp.json().get("result") or {}).get("value", 0) / 10 ** 9
            print(f"[SOL] SOL balance: {sol_bal}")
            if sol_bal > 0.0001:
                sol_native = round(sol_bal, 8)

            # 2. SPL tokens via Moralis Solana Gateway
            if MORALIS_API_KEY:
                moralis_headers = {"accept": "application/json", "X-API-Key": MORALIS_API_KEY}
                spl_url = f"https://solana-gateway.moralis.io/account/mainnet/{raw_addr}/tokens"
                try:
                    spl_resp = _requests.get(spl_url, headers=moralis_headers, timeout=8)
                    print(f"[SOL] Moralis SPL status: {spl_resp.status_code}")
                    if spl_resp.status_code == 200:
                        for tok in spl_resp.json():
                            symbol = tok.get("symbol", "")
                            if not symbol:
                                continue
                            # Moralis Solana API returns 'amount' already human-readable
                            ui_bal = float(tok.get("amount") or 0)
                            _STABLE = {"USDC", "USDT", "DAI", "BUSD", "FDUSD"}
                            tok_usd = float(tok.get("usd_value") or 0.0)
                            if tok_usd <= 0 and symbol.upper() in _STABLE:
                                tok_usd = ui_bal
                            if _passes_balance_filter(tok, tok_usd, ui_bal):
                                sym_up = symbol.upper()
                                if sym_up in sol_seen:
                                    continue
                                sol_seen.add(sym_up)
                                print(f"[SOL] SPL token: {symbol} bal={ui_bal}")
                                sol_tokens.append({"symbol": symbol, "balance": round(ui_bal, 6), "usd_value": round(tok_usd, 4)})
                    else:
                        print(f"[SOL] Moralis SPL error: {spl_resp.text[:200]}")
                except Exception as spl_exc:
                    print(f"[SOL] Moralis SPL failed: {spl_exc}")

        except Exception as exc:
            print(f"[SOL] Error: {exc}")

        if sol_native == 0.0 and not sol_tokens:
            return []
        # Post-process dedup for Solana SPL tokens
        unique_sol: dict[str, dict] = {}
        for t in sol_tokens:
            k = t["symbol"].upper()
            if k not in unique_sol:
                unique_sol[k] = t
        sol_tokens = list(unique_sol.values())
        sol_price = _get_price_usd("SOL")
        native_usd = round(sol_native * sol_price, 4)
        sol_usd = native_usd + sum(t.get("usd_value", 0.0) for t in sol_tokens)
        return [{"chain": "Solana", "native_symbol": "SOL",
                 "native_balance": sol_native, "native_usd": native_usd,
                 "tokens": sol_tokens, "usd_total": round(sol_usd, 2)}]

    # ── EVM chains (concurrent) ─────────────────────────────────────────────
    try:
        evm_address = Web3.to_checksum_address(raw_addr)
    except ValueError:
        return []

    evm_chains = [
        c for c in _BALANCE_CHAINS
        if c.get("type") != "solana"
        and (not target_chain or c["name"] == target_chain)
    ]

    # Pre-fetch prices once for all unique native symbols
    unique_natives = {c["native"] for c in evm_chains}
    native_prices: dict[str, float] = {sym: _get_price_usd(sym) for sym in unique_natives}

    def check_evm(chain: dict) -> Optional[dict]:
        chain_name = chain["name"]
        native_sym = chain["native"]
        native_balance = 0.0
        usd_total_chain = 0.0
        tokens: list[dict] = []
        seen_symbols: set[str] = {native_sym.upper()}  # pre-seed with native to block duplicates

        def rpc_post(payload: dict) -> dict:
            for rpc in chain["rpcs"]:
                try:
                    r = _requests.post(rpc, json=payload, timeout=3)
                    data = r.json()
                    if "result" in data:
                        return data
                except Exception:
                    continue
            return {}

        # 1. Native balance via RPC
        try:
            d = rpc_post({"jsonrpc": "2.0", "method": "eth_getBalance",
                          "params": [evm_address, "latest"], "id": 1})
            h = d.get("result", "0x0") or "0x0"
            if h not in ("0x", "0x0", "0x00"):
                bal = int(h, 16) / 10 ** 18
                if bal > 0.0001:
                    native_balance = round(bal, 8)
                    usd_total_chain += native_balance * native_prices.get(native_sym, 0.0)
        except Exception:
            pass

        # 2. ERC-20 tokens via Moralis API (no hardcoded contracts)
        moralis_chain = _MORALIS_CHAINS.get(chain_name)
        if moralis_chain and MORALIS_API_KEY:
            url = f"https://deep-index.moralis.io/api/v2.2/wallets/{evm_address}/tokens?chain={moralis_chain}"
            headers = {"accept": "application/json", "X-API-Key": MORALIS_API_KEY}
            for attempt in range(3):
                try:
                    tok_resp = _requests.get(url, headers=headers, timeout=8)
                    if tok_resp.status_code == 429:
                        print(f"[Moralis] {chain_name}: 429 rate limit, attempt {attempt + 1}/3")
                        time.sleep(1.5)
                        continue
                    if tok_resp.status_code == 200:
                        _SPAM_TICKERS = {"FL", "SIGN", "EC", "GPT", "XAI", "LP-USDT", "AWSAI", "C3 Coin", "MA", "毒王", "比特币", "Claude"}
                        tokens_to_verify: dict[str, dict] = {}

                        # 1. Primary collection + spam filter
                        for tok in tok_resp.json().get("result", []):
                            symbol = tok.get("symbol", "Unknown")
                            if symbol in _SPAM_TICKERS:
                                continue
                            decimals = int(tok.get("decimals", 18))
                            ui_bal = float(tok.get("balance", 0)) / (10 ** decimals)
                            token_usd = float(tok.get("usd_value") or 0)
                            token_address = tok.get("token_address", "").lower()
                            if _passes_balance_filter(tok, token_usd, ui_bal):
                                tokens_to_verify[token_address] = {
                                    "symbol": symbol,
                                    "balance": ui_bal,
                                    "moralis_usd": token_usd,
                                    "possible_spam": tok.get("possible_spam", False),
                                }

                        # 2. DexScreener liquidity check (batch, free, no key needed)
                        dex_data_map: dict[str, dict] = {}
                        if tokens_to_verify:
                            addresses_str = ",".join(list(tokens_to_verify.keys())[:30])
                            dex_url = f"https://api.dexscreener.com/latest/dex/tokens/{addresses_str}"
                            try:
                                dex_resp = _requests.get(dex_url, timeout=5)
                                if dex_resp.status_code == 200:
                                    for pair in dex_resp.json().get("pairs") or []:
                                        t_addr = pair.get("baseToken", {}).get("address", "").lower()
                                        liq = float((pair.get("liquidity") or {}).get("usd") or 0)
                                        vol = float((pair.get("volume") or {}).get("h24") or 0)
                                        price_usd = float(pair.get("priceUsd") or 0)
                                        if t_addr not in dex_data_map or liq > dex_data_map[t_addr]["liq"]:
                                            dex_data_map[t_addr] = {"liq": liq, "vol": vol, "price": price_usd}
                            except Exception as dex_exc:
                                print(f"[DexScreener] {chain_name}: {dex_exc}")

                        # 3. Build final token list with verified USD
                        _BLUECHIP = {"USDC", "USDT", "DAI", "WBTC", "WETH", "ETH", "BNB", "WBNB", "AVAX", "CAKE", "MATIC"}
                        for addr, t_data in tokens_to_verify.items():
                            symbol = t_data["symbol"]
                            ui_bal = t_data["balance"]
                            trusted_usd = t_data["moralis_usd"]
                            if symbol not in _BLUECHIP:
                                dex = dex_data_map.get(addr, {"liq": 0, "vol": 0, "price": 0.0})
                                # Use real DEX price instead of Moralis estimate
                                trusted_usd = ui_bal * dex["price"]
                                # Dead pool: insufficient liquidity or volume → zero out
                                if dex["liq"] < 2000 or dex["vol"] < 100:
                                    trusted_usd = 0.0
                            sym_up = symbol.upper()
                            if sym_up in seen_symbols:
                                continue
                            seen_symbols.add(sym_up)
                            if _passes_balance_filter(t_data, trusted_usd, ui_bal):
                                tokens.append({"symbol": symbol, "balance": round(ui_bal, 6), "usd_value": round(trusted_usd, 4)})
                                usd_total_chain += trusted_usd
                    else:
                        print(f"[Moralis] {chain_name}: HTTP {tok_resp.status_code}")
                    break
                except Exception as e:
                    print(f"[Moralis] Error on {chain_name} (attempt {attempt + 1}/3): {e}")
                    time.sleep(1.0)

        if native_balance == 0.0 and not tokens:
            return None
        # Post-process dedup: keep first occurrence per symbol (native always wins, it was pre-seeded)
        unique: dict[str, dict] = {}
        for t in tokens:
            k = t["symbol"].upper()
            if k not in unique:
                unique[k] = t
        tokens = list(unique.values())
        native_usd = round(native_balance * native_prices.get(native_sym, 0.0), 4)
        return {"chain": chain_name, "native_symbol": native_sym,
                "native_balance": native_balance, "native_usd": native_usd,
                "tokens": tokens, "usd_total": round(usd_total_chain, 2)}

    chain_dicts: list[dict] = []
    for chain in evm_chains:
        try:
            res = check_evm(chain)
            if res:
                chain_dicts.append(res)
        except Exception:
            pass

    return chain_dicts


def get_smart_wallet_balance(addr_input: str, user_address: str = "", solana_address: str = "") -> str:
    """
    Checks balances for one or more addresses (comma-separated).
    Phantom dual-chain wallets send "solAddr,evmAddr" — both are scanned.
    Supports 'address|chain' pipe filter (applied to all addresses).
    """
    # Parse optional pipe chain filter
    if "|" in addr_input:
        addr_part, chain_filter = addr_input.split("|", 1)
        chain_filter = chain_filter.strip().lower()
    else:
        addr_part, chain_filter = addr_input, ""

    # Split by comma for multi-address (Phantom dual-chain)
    raw_addrs = [a.strip() for a in addr_part.split(",") if a.strip()]
    if not raw_addrs:
        # Fall back to injected user/solana addresses
        for fallback in [user_address, solana_address]:
            for a in fallback.split(","):
                a = a.strip()
                if a:
                    raw_addrs.append(a)
    if not raw_addrs:
        return "No wallet address provided."

    target_chain = _CHAIN_ALIASES.get(chain_filter.replace(" ", ""), "") if chain_filter else ""

    wallet_addresses: list[str] = []
    all_balances: list[dict] = []
    for addr in raw_addrs:
        wallet_addresses.append(addr)
        chain_entries = _scan_single_address(addr, target_chain)
        all_balances.extend(chain_entries)

    total_usd = round(sum(entry.get("usd_total", 0.0) for entry in all_balances), 2)
    result: dict = {
        "type": "balance_report",
        "wallet_addresses": wallet_addresses,
        "balances": all_balances,
        "total_usd": total_usd,
    }
    if not all_balances:
        result["message"] = "No balances found across any chain."
    return json.dumps(result)


def _simulate_swap(raw_input: str, chain_id: int) -> str:
    """
    Calls the 1inch Quote API v6 to estimate swap output.

    Input format (space-separated):
        TOKEN_IN_ADDRESS TOKEN_OUT_ADDRESS AMOUNT_WEI

    If the requested chain is not supported by 1inch,
    the quote is fetched against BNB Smart Chain (56) instead.
    """
    parts = raw_input.strip().split()
    if len(parts) != 3:
        return (
            "Usage: TOKEN_IN_ADDRESS TOKEN_OUT_ADDRESS AMOUNT_WEI  "
            "(space-separated, amounts in wei)"
        )
    src, dst, amount = parts

    effective_chain = chain_id if chain_id in _ONEINCH_SUPPORTED else 56
    if effective_chain != chain_id:
        chain_note = f" (1inch does not support chain {chain_id}; using BSC {effective_chain})"
    else:
        chain_note = ""

    api_key = settings.api_keys.get("oneinch", "")
    headers = {"Authorization": f"Bearer {api_key}", "Accept": "application/json"}

    url = f"https://api.1inch.dev/swap/v6.0/{effective_chain}/quote"
    params = {"src": src, "dst": dst, "amount": amount}

    try:
        resp = httpx.get(url, params=params, headers=headers, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        dst_amount = data.get("dstAmount", "N/A")
        gas = data.get("gas", "N/A")
        return (
            f"Swap quote{chain_note}: {amount} wei {src} → {dst_amount} wei {dst}  "
            f"| estimated gas: {gas}"
        )
    except httpx.HTTPStatusError as exc:
        return f"1inch API error {exc.response.status_code}: {exc.response.text[:300]}"
    except Exception as exc:
        logger.warning("simulate_swap error: %s", exc)
        return f"Swap simulation failed: {exc}"


def _get_token_price(token_input: str) -> str:
    """
    Returns the current USD price.  Tries Binance first (fast, no key),
    falls back to CoinGecko (accepts both symbol and CoinGecko ID).
    """
    symbol = token_input.strip().upper()
    coin_id = token_input.strip().lower()

    # --- Binance ---
    try:
        resp = httpx.get(
            "https://api.binance.com/api/v3/ticker/price",
            params={"symbol": f"{symbol}USDT"},
            timeout=5,
        )
        if resp.status_code == 200:
            price = resp.json().get("price", "N/A")
            return f"{symbol}/USDT = ${price} (Binance)"
    except Exception:
        pass

    # --- CoinGecko fallback ---
    try:
        resp = httpx.get(
            "https://api.coingecko.com/api/v3/simple/price",
            params={"ids": coin_id, "vs_currencies": "usd"},
            timeout=8,
        )
        resp.raise_for_status()
        data = resp.json()
        if coin_id in data:
            price = data[coin_id]["usd"]
            return f"{coin_id} = ${price} USD (CoinGecko)"
        return (
            f"Token '{token_input}' not found. "
            "Try the CoinGecko ID (e.g. 'binancecoin' for BNB, 'bitcoin' for BTC)."
        )
    except Exception as exc:
        logger.warning("get_token_price error for %s: %s", token_input, exc)
        return f"Price lookup failed: {exc}"


# ---------------------------------------------------------------------------
# Platform referral / fee configuration
# ---------------------------------------------------------------------------

# 1inch: percentage string, range 0.0–3.0  (1.0 = 1 %)
_REFERRAL_FEE_PCT: Final = 1.0

# Jupiter: basis points integer  (50 = 0.5 %)
_PLATFORM_FEE_BPS: Final = 50


def _referrer_address() -> str:
    """EVM address that receives 1inch referral fees (set via API_KEYS env var)."""
    return settings.api_keys.get("referrer_address", "")


def _jupiter_fee_account() -> str:
    """Solana Associated Token Account that receives Jupiter platform fees."""
    return settings.api_keys.get("jupiter_fee_account", "")


# ---------------------------------------------------------------------------
# build_swap_tx helpers
# ---------------------------------------------------------------------------

def _build_oneinch_swap_tx(
    params: dict[str, Any],
    user_address: str,
    default_chain_id: int,
) -> str:
    """
    Calls 1inch Aggregation Protocol v6 /swap to build a ready-to-sign EVM tx.

    Required keys in `params`: token_in, token_out, amount
    Optional keys:  chain_id, from (wallet), slippage_bps (default 100 = 1 %)
    """
    chain_id = int(params.get("chain_id", default_chain_id))
    effective_chain = chain_id if chain_id in _ONEINCH_SUPPORTED else 56
    chain_note = (
        f"Note: chain {chain_id} not supported by 1inch — used BSC ({effective_chain}). "
        if effective_chain != chain_id
        else ""
    )

    src = params.get("token_in", "")
    dst = params.get("token_out", "")
    amount = str(params.get("amount", ""))
    from_addr = params.get("from", user_address).strip() or user_address
    slippage_pct = int(params.get("slippage_bps", 100)) / 100  # bps → percent

    if not (src and dst and amount):
        return json.dumps(
            {"status": "error", "message": "token_in, token_out and amount are required"}
        )

    referrer = _referrer_address()
    api_key = settings.api_keys.get("oneinch", "")
    headers = {"Authorization": f"Bearer {api_key}", "Accept": "application/json"}

    query: dict[str, Any] = {
        "src": src,
        "dst": dst,
        "amount": amount,
        "from": from_addr,
        "slippage": slippage_pct,
        "disableEstimate": False,
    }
    # Attach referral fee only when an address is configured
    if referrer:
        query["fee"] = _REFERRAL_FEE_PCT       # platform fee in percent
        query["referrerAddress"] = referrer     # fee destination

    url = f"https://api.1inch.dev/swap/v6.0/{effective_chain}/swap"

    try:
        resp = httpx.get(url, params=query, headers=headers, timeout=15)
        resp.raise_for_status()
        data = resp.json()
    except httpx.HTTPStatusError as exc:
        return json.dumps(
            {
                "status": "error",
                "message": f"1inch API {exc.response.status_code}: {exc.response.text[:300]}",
            }
        )
    except Exception as exc:
        logger.warning("build_swap_tx / 1inch error: %s", exc)
        return json.dumps({"status": "error", "message": str(exc)})

    raw_tx: dict[str, Any] = data.get("tx", {})
    result: dict[str, Any] = {
        "status": "ok",
        "chain_type": "evm",
        "chain_id": effective_chain,
        "dst_amount": data.get("dstAmount"),
        "referral_fee_pct": _REFERRAL_FEE_PCT if referrer else 0,
        "referrer_address": referrer,
        # tx is ready for eth_sendTransaction / eth_signTransaction
        "tx": {
            "from": raw_tx.get("from", from_addr),
            "to": raw_tx.get("to"),
            "data": raw_tx.get("data"),
            "value": raw_tx.get("value", "0x0"),
            "gas": raw_tx.get("gas"),
            "gasPrice": raw_tx.get("gasPrice"),
        },
    }
    if chain_note:
        result["warning"] = chain_note
    return json.dumps(result)


def _build_jupiter_swap_tx(params: dict[str, Any]) -> str:
    """
    Calls Jupiter Aggregator v6 (quote → swap) to build a ready-to-sign
    Solana transaction with platform fee.

    Required keys in `params`: token_in (inputMint), token_out (outputMint),
                                amount (in base units), from (userPublicKey)
    Optional keys:  slippage_bps (default 50)
    """
    input_mint = params.get("token_in", "")
    output_mint = params.get("token_out", "")
    amount = params.get("amount", "")
    user_pubkey = params.get("from", "")
    slippage_bps = int(params.get("slippage_bps", 50))
    fee_account = _jupiter_fee_account()

    if not (input_mint and output_mint and amount and user_pubkey):
        return json.dumps(
            {
                "status": "error",
                "message": "token_in, token_out, amount and from (Solana pubkey) are required",
            }
        )

    # --- Step 1: Quote ---
    quote_params: dict[str, Any] = {
        "inputMint": input_mint,
        "outputMint": output_mint,
        "amount": int(amount),
        "slippageBps": slippage_bps,
        "platformFeeBps": _PLATFORM_FEE_BPS,
    }

    try:
        quote_resp = httpx.get(
            "https://public.jupiterapi.com/quote",
            params=quote_params,
            timeout=10,
        )
        quote_resp.raise_for_status()
        quote_data: dict[str, Any] = quote_resp.json()
    except httpx.HTTPStatusError as exc:
        return json.dumps(
            {
                "status": "error",
                "message": f"Jupiter quote error {exc.response.status_code}: {exc.response.text[:300]}",
            }
        )
    except Exception as exc:
        logger.warning("build_swap_tx / Jupiter quote error: %s", exc)
        return json.dumps({"status": "error", "message": str(exc)})

    # --- Step 2: Serialised swap transaction ---
    swap_body: dict[str, Any] = {
        "quoteResponse": quote_data,
        "userPublicKey": user_pubkey,
        "wrapAndUnwrapSol": True,   # handle native SOL transparently
        "dynamicComputeUnitLimit": True,
        "prioritizationFeeLamports": "auto",
    }
    # feeAccount must be an existing ATA for outputMint owned by the platform
    if fee_account:
        swap_body["feeAccount"] = fee_account

    try:
        swap_resp = httpx.post(
            "https://public.jupiterapi.com/swap",
            json=swap_body,
            timeout=15,
        )
        swap_resp.raise_for_status()
        swap_data: dict[str, Any] = swap_resp.json()
    except httpx.HTTPStatusError as exc:
        return json.dumps(
            {
                "status": "error",
                "message": f"Jupiter swap error {exc.response.status_code}: {exc.response.text[:300]}",
            }
        )
    except Exception as exc:
        logger.warning("build_swap_tx / Jupiter swap error: %s", exc)
        return json.dumps({"status": "error", "message": str(exc)})

    result: dict[str, Any] = {
        "status": "ok",
        "chain_type": "solana",
        "out_amount": quote_data.get("outAmount"),
        # minimum received after slippage — use for UI display
        "out_amount_min": quote_data.get("otherAmountThreshold"),
        "price_impact_pct": quote_data.get("priceImpactPct"),
        "platform_fee_bps": _PLATFORM_FEE_BPS,
        "fee_account": fee_account,
        # tx.serialized is a base64 VersionedTransaction ready for
        # signTransaction / sendRawTransaction via a Solana wallet adapter
        "tx": {
            "serialized": swap_data.get("swapTransaction"),
            "last_valid_block_height": swap_data.get("lastValidBlockHeight"),
        },
    }
    return json.dumps(result)


def _build_swap_tx(raw_input: str, user_address: str, chain_id: int) -> str:
    """
    Dispatcher: routes to 1inch (EVM) or Jupiter (Solana) based on `chain`.

    Input: JSON string with keys:
        chain        "evm" | "solana"  (default "evm")
        token_in     token address / mint
        token_out    token address / mint
        amount       amount in wei (EVM) or base units (Solana)
        from         sender wallet — omit to use the session user's address
        chain_id     EVM chain ID (default = session chain_id, ignored for Solana)
        slippage_bps slippage tolerance in basis points (default 100 EVM / 50 SOL)
    """
    try:
        params: dict[str, Any] = json.loads(raw_input)
    except json.JSONDecodeError as exc:
        return json.dumps({"status": "error", "message": f"JSON parse error: {exc}"})

    chain = str(params.get("chain", "evm")).lower()
    if chain == "solana":
        return _build_jupiter_swap_tx(params)
    return _build_oneinch_swap_tx(params, user_address, chain_id)


# ---------------------------------------------------------------------------
# build_transfer_transaction
# ---------------------------------------------------------------------------

def _is_native(symbol_lower: str, chain_id: int) -> bool:
    """Return True if the symbol is the native coin for the given chain."""
    native = _native_symbol(chain_id).lower()
    return symbol_lower in {native, "native"} or (symbol_lower == "sol" and chain_id == 0)


def _build_transfer_transaction(raw_input: str, chain_id: int = 56) -> str:
    """
    Builds a ready-to-sign transfer transaction (native coin or ERC-20).

    Automatically resolves contract address and decimals using the per-chain
    TOKENS_BY_CHAIN registry — no external calls needed.

    Input: JSON string with keys:
        token_symbol   required — e.g. "BNB", "USDT", "USDC"
        amount         required — float, e.g. 0.5
        to_address     required — recipient wallet address (0x…)
        token_address  optional — ERC-20 contract; auto-resolved for known tokens;
                       omit or set to "native" for BNB
        decimals       optional — auto-resolved for known tokens (default 18)
    """
    try:
        params: dict[str, Any] = json.loads(raw_input)
    except json.JSONDecodeError as exc:
        return json.dumps({"status": "error", "message": f"JSON parse error: {exc}"})

    token_symbol: str = str(params.get("token_symbol", "")).strip()
    amount_raw = params.get("amount")
    to_address: str = str(params.get("to_address", "")).strip()
    token_address: Optional[str] = params.get("token_address")
    decimals: Optional[int] = params.get("decimals")

    if not to_address or amount_raw is None:
        return json.dumps(
            {"status": "error", "message": "to_address and amount are required"}
        )

    try:
        amount = float(amount_raw)
    except (TypeError, ValueError):
        return json.dumps({"status": "error", "message": "amount must be a number"})

    if amount <= 0:
        return json.dumps({"status": "error", "message": "amount must be greater than 0"})

    symbol_lower = token_symbol.lower()

    # Allow agent to override chain_id via JSON (e.g. AVAX → chain 43114)
    if "chain_id" in params:
        try:
            chain_id = int(params["chain_id"])
        except (TypeError, ValueError):
            pass

    # Auto-detect chain from unique native symbol (e.g. "avax" → 43114, "ftm" → 250)
    if symbol_lower in _NATIVE_SYMBOL_TO_CHAIN and chain_id not in _NATIVE_SYMBOL_TO_CHAIN.values():
        detected = _NATIVE_SYMBOL_TO_CHAIN[symbol_lower]
        if _native_symbol(detected).lower() == symbol_lower:
            chain_id = detected

    # Pick the right token registry for the resolved chain
    token_registry = TOKENS_BY_CHAIN.get(chain_id, {})
    chain_label = _chain_name(chain_id)

    # ── Auto-resolve from registry if token_address not provided ────────────
    if not token_address or str(token_address).lower() in ("native", ""):
        if _is_native(symbol_lower, chain_id):
            token_address = None  # native coin transfer
        elif symbol_lower in token_registry:
            entry = token_registry[symbol_lower]
            token_address = entry["address"]
            if decimals is None:
                decimals = entry["decimals"]
        else:
            # Check if the token exists on any other supported chain
            found_on = [_chain_name(cid) for cid, reg in TOKENS_BY_CHAIN.items() if symbol_lower in reg]
            if found_on:
                return json.dumps({
                    "status": "error",
                    "message": (
                        f"Token '{token_symbol}' is not available on {chain_label} (chain {chain_id}). "
                        f"It is supported on: {', '.join(found_on)}. "
                        "Switch the network in MetaMask or provide token_address + decimals manually."
                    ),
                })
            return json.dumps({
                "status": "error",
                "message": (
                    f"Unknown token '{token_symbol}' on {chain_label}. "
                    "Please provide token_address and decimals explicitly."
                ),
            })
    else:
        # token_address was explicitly provided — just normalise decimals
        if decimals is None:
            decimals = token_registry.get(symbol_lower, {}).get("decimals", 18)

    # ── Native coin transfer (BNB / ETH / MATIC …) ──────────────────────────
    if not token_address:
        wei_amount = hex(int(amount * (10 ** 18)))
        result: dict[str, Any] = {
            "status": "ok",
            "type": "transaction",
            "chain_id": chain_id,           # network where tx must be sent
            "token_symbol": token_symbol,
            "amount": amount,
            "to": to_address,               # recipient (native: directly to recipient)
            "ui_to": to_address,            # human-readable recipient for UI display
            "data": "0x",
            "value": wei_amount,
        }
        return json.dumps(result)

    # ── ERC-20 transfer: transfer(address,uint256) selector = 0xa9059cbb ────
    effective_decimals: int = decimals if decimals is not None else 18
    method_id = "a9059cbb"
    clean_to = to_address.replace("0x", "").lower().zfill(64)
    wei_amount_int = int(amount * (10 ** effective_decimals))
    hex_amount = hex(wei_amount_int).replace("0x", "").zfill(64)
    calldata = f"0x{method_id}{clean_to}{hex_amount}"

    result = {
        "status": "ok",
        "type": "transaction",
        "chain_id": chain_id,           # network where tx must be sent
        "token_symbol": token_symbol,
        "amount": amount,
        "to": token_address,            # ERC-20 contract address (call target)
        "ui_to": to_address,            # human-readable recipient for UI display
        "data": calldata,               # encoded transfer(to, amount)
        "value": "0x0",
    }
    return json.dumps(result)


# ---------------------------------------------------------------------------
# System prompt — dynamic, includes chain context
# ---------------------------------------------------------------------------

def _build_system_prompt(chain_id: int, user_address: str = "", solana_address: str = "") -> str:
    """Return a system prompt tailored to the user's current network."""
    chain_label = _chain_name(chain_id)
    native = _native_symbol(chain_id)

    wallet_line = (
        f"Connected EVM wallet: {user_address}"
        if user_address
        else "Connected EVM wallet: none"
    )
    solana_line = (
        f"Connected Solana wallet (Phantom): {solana_address}"
        if solana_address
        else ""
    )
    my_balance_line = (
        f'  - "my balance" or "all chains" (EVM) → input: "{user_address}"'
        if user_address
        else f'  - "my balance" → input: "{solana_address}" (Solana-only wallet, use Solana address directly)'
    )

    return f"""\
You are a Senior DeFi Advisor — an expert in crypto, DeFi protocols, and Web3. \
You are both a smart conversationalist and a precise technical executor. \
You respond in the same language the user writes in.

Active network: {chain_label} (chain ID {chain_id}). Native coin: {native}.
{wallet_line}
{solana_line}

━━━ BEHAVIOR RULES ━━━

1. MACRO MARKET QUESTIONS — use get_defi_market_overview
   Trigger: user asks general questions about the DeFi market, trends, sentiment, or outlook.
   Examples: "What do you think about DeFi?", "How is DeFi doing?", "Which chain is leading?",
             "DeFi market overview", "What are DeFi trends?", "Is it a good time for DeFi?"
   Action: call get_defi_market_overview(""), then write a detailed professional analysis
   combining the live TVL data with your expert knowledge. Use formatting, bullet points,
   and emojis. Be like a seasoned crypto analyst giving a market briefing.

2. YIELD / POOL STRATEGY — use get_defi_analytics
   Trigger: user asks about APY, APR, yield farming, staking, best pools, passive income,
             "where to stake X", "best pools on Y chain", "highest APR/APY".
   Action: call get_defi_analytics with the relevant token/chain/protocol.
   IMPORTANT — sorting:
     - If user asks for "highest APR", "highest APY", "best yield", "top APY",
       "highest return", or any max-yield request: add "sort:apy" to the input.
       Example: user says "highest APR pool on Solana" → input: "solana sort:apy"
       Example: user says "best yield for SOL" → input: "SOL solana sort:apy"
     - Otherwise omit sort (defaults to TVL = safest/most liquid).
   Note: DefiLlama provides APY (compound), not APR. If user asks for APR,
   use APY data and briefly mention "APY (compound rate)" in your response.
   The tool returns structured JSON — output it VERBATIM as Final Answer.

3. CONTRACT ADDRESS / MEME COIN LOOKUP — use search_dexscreener_pairs
   Trigger: user provides a raw CONTRACT ADDRESS (long alphanumeric string, e.g. Solana mint
   or EVM address), OR asks "where to trade this token", "is this listed", "find pairs for X",
   OR mentions a meme coin / newly launched token that may not be in DefiLlama.
   Examples: "AetrqKMG...pump", "where can I buy this token?", "find pairs for BONK".
   Action: call search_dexscreener_pairs with the address or token name. Then write a
   clear analyst response: which DEX it trades on, liquidity, volume, and direct link.
   Be helpful — if it's on Raydium, say so explicitly and provide the link.

3.5. POOL LOOKUP (FARMING / TVL) — use find_liquidity_pool
   Trigger: user asks for a specific liquidity pool for KNOWN pairs (stablecoins, majors)
   to farm yield, or explicitly asks for a pool address.
   Examples: "find USDC/USDT pool on BSC", "WBNB CAKE pool address".
   Action: call find_liquidity_pool, then output the JSON result VERBATIM as Final Answer.
   The frontend renders it as a visual card — do NOT wrap it in text or markdown.

4. WALLET BALANCE — use get_wallet_balance
   Trigger: ANY balance query ("my balance", "what do I have", "баланс").
{my_balance_line}
   - To check a specific chain: input "{user_address or solana_address}|<chain>"
     chain keywords: eth, bnb, polygon, arbitrum, optimism, base, avalanche, zksync,
     linea, scroll, mantle, fantom, gnosis, celo, cronos, solana
   - NEVER ask the user for their address — use the addresses above.
   - Output the JSON result VERBATIM as Final Answer (renders as visual card).

5. TOKEN PRICE — use get_token_price
   Trigger: user asks for price of any token.

6. SWAP / TRANSFER — use build_swap_tx / build_transfer_tx / build_solana_swap
   - For Solana swaps (solana_address is set): ALWAYS use build_solana_swap, never build_swap_tx.
   - For "send all [token]": first call get_wallet_balance to find amount, then transfer.
   - CRITICAL: After calling build_solana_swap, your Final Answer MUST follow this EXACT format
     (no markdown code blocks, no extra text after the JSON):

Thought: I now have the transaction data.
Final Answer: {{{{"type":"solana_swap_proposal","swapTransaction":"...","ui_out_amount":1.5,"out_symbol":"USDC",...}}}}

     NEVER add any text after Final Answer: except the JSON object itself.
   - Same rule for build_swap_tx and build_transfer_tx — Final Answer must be JSON only.

━━━ RESPONSE FORMAT RULES (КРИТИЧЕСКИ ВАЖНО) ━━━

A. ТРАНЗАКЦИИ (build_solana_swap / build_swap_tx / build_transfer_tx):
   Final Answer должен быть СТРОГО чистым JSON-объектом без markdown и без текста до/после.
   Пример: Final Answer: {{{{"type":"solana_swap_proposal","swapTransaction":"...",...}}}}

B. СПИСКИ С ДАННЫМИ (search_dexscreener_pairs, find_liquidity_pool и любой ответ со списком сущностей):
   Ты ОБЯЗАН вернуть JSON-объект типа "universal_cards". Не используй Markdown-списки!
   Формат строго такой (экранируй кавычки внутри строк):
   Final Answer: {{{{"type":"universal_cards","message":"Короткий текст для пользователя","cards":[{{{{"title":"ТОКЕН/SOL","subtitle":"Raydium · Solana","details":{{{{"Price":"$0.01","Liquidity":"$50,000","Volume 24h":"$120,000"}}}},"url":"https://dexscreener.com/...","button_text":"Trade"}}}}]}}}}

C. ПРОСТЫЕ ВОПРОСЫ И АНАЛИТИКА (без списков сущностей):
   Final Answer — обычный текст на языке пользователя. Можно использовать **жирный** и эмодзи.

7. CASUAL / GENERAL CONVERSATION — no tools needed
   Trigger: greetings, small talk, general questions about yourself, how you work,
            personal questions ("how are you?", "who made you?", "what can you do?",
            "hello", "hi", "thanks", "you're great"), opinion questions not requiring
            live data, or anything that doesn't require a blockchain tool.
   Action: respond DIRECTLY as Final Answer — warm, friendly, and natural.
   You have a personality: curious, enthusiastic about crypto, professional but approachable.
   Never say "I'm just an AI" — you are a Senior DeFi Advisor with deep expertise and a
   genuine interest in helping users navigate the crypto world.
   Examples:
     User: "Hello!" → Final Answer: Hey! 👋 Great to have you here. I'm your AI DeFi advisor — ready to help with prices, swaps, yields, or just talk crypto. What's on your mind?
     User: "How are you?" → Final Answer: Doing great, thanks for asking! 😄 Markets are moving fast today — anything you'd like to check on?
     User: "What can you do?" → Final Answer: Lots! I can check your wallet balances, get live token prices, find the best yield pools, build swap transactions, and even chat about DeFi strategies. Just ask!

━━━ GENERAL RULES ━━━
- Never give personalized financial investment advice.
- Always include units ({native}, USDT, etc.) with numeric values.
- Be empathetic, professional, and engaging — like an experienced crypto-native advisor.
- For greetings and casual messages, NEVER call any tool. Respond conversationally and warmly.
- CRITICAL: Never output raw ReAct format (Question:/Thought:/Action:/Action Input:) in your
  Final Answer. The Final Answer must always be clean, readable text or valid JSON — never
  the internal reasoning trace.

Conversation so far:
{{chat_history}}"""


# ---------------------------------------------------------------------------
# Step 3.5 — DeFi analytics via DefiLlama (no API key required)
# ---------------------------------------------------------------------------

_CHAIN_ALIASES_LLAMA: dict[str, str] = {
    "bnb": "bsc", "bsc": "bsc", "bnbchain": "bsc",
    "eth": "ethereum", "ethereum": "ethereum",
    "polygon": "polygon", "matic": "polygon",
    "arbitrum": "arbitrum", "arb": "arbitrum",
    "optimism": "optimism", "op": "optimism",
    "base": "base",
    "avalanche": "avalanche", "avax": "avalanche",
    "solana": "solana", "sol": "solana",
    "fantom": "fantom", "ftm": "fantom",
    "gnosis": "gnosis",
}


def get_defi_market_overview(_: str = "") -> str:
    """
    Fetches a live macro overview of the DeFi market from DefiLlama:
    top blockchains by TVL, total market TVL, and dominance breakdown.
    Use this for general questions about the DeFi market state, trends, or outlook.
    No input required — pass an empty string or any value.
    """
    try:
        resp = _requests.get("https://api.llama.fi/v2/chains", timeout=12)
        if resp.status_code != 200:
            return f"DefiLlama API error: HTTP {resp.status_code}"

        chains: list[dict] = resp.json()
        chains.sort(key=lambda c: c.get("tvl") or 0, reverse=True)
        top = chains[:10]

        total_tvl = sum(c.get("tvl") or 0 for c in chains)
        top_tvl   = sum(c.get("tvl") or 0 for c in top)

        lines = [
            f"DeFi Market Overview (live data from DefiLlama):",
            f"Total DeFi TVL across all chains: ${total_tvl:,.0f}",
            f"",
            f"Top 10 blockchains by TVL:",
        ]
        for i, c in enumerate(top, 1):
            name   = c.get("name", "—")
            tvl    = c.get("tvl") or 0
            share  = tvl / total_tvl * 100 if total_tvl else 0
            lines.append(f"  {i}. {name}: ${tvl:,.0f} ({share:.1f}% dominance)")

        lines += [
            f"",
            f"Top 10 chains hold ${top_tvl:,.0f} ({top_tvl/total_tvl*100:.1f}% of total TVL).",
        ]
        return "\n".join(lines)

    except Exception as exc:
        return f"DefiLlama error: {exc}"


def get_defi_analytics(query: str) -> str:
    """
    Fetches live yield/pool data from DefiLlama and returns top-5 pools
    filtered by token symbol, chain, and/or protocol.
    Returns structured universal_cards JSON with protocol URLs.

    Input examples:
      "USDC"                   – best USDC pools across all chains (by TVL)
      "USDC polygon"           – best USDC pools on Polygon (by TVL)
      "aave"                   – best pools in Aave protocol (by TVL)
      "ETH arbitrum"           – ETH pools on Arbitrum (by TVL)
      "RAY solana"             – RAY pools on Solana (by TVL)
      "SOL solana sort:apy"    – highest-APY SOL pools on Solana
      "solana sort:apy"        – highest-APY pools on Solana (any token)
    """
    try:
        resp = _requests.get("https://yields.llama.fi/pools", timeout=12)
        if resp.status_code != 200:
            return f"DefiLlama API error: HTTP {resp.status_code}"

        all_pools: list[dict] = resp.json().get("data", [])

        # Parse query into token / chain / protocol / sort filters
        parts = query.strip().split()
        token_filter = ""
        chain_filter = ""
        protocol_filter = ""
        sort_by = "tvl"  # default: sort by TVL (safest/most liquid)

        for part in parts:
            lower = part.lower()
            # Explicit sort directive: sort:apy or sort:tvl
            if lower.startswith("sort:"):
                sort_by = lower.split(":", 1)[1]
                continue
            mapped_chain = _CHAIN_ALIASES_LLAMA.get(lower, "")
            if mapped_chain:
                chain_filter = mapped_chain
            elif not token_filter:
                token_filter = part.upper()
            else:
                protocol_filter = lower

        # Lower TVL floor when sorting by yield to include smaller high-APY pools
        tvl_floor = 10_000 if sort_by == "apy" else 50_000

        filtered: list[dict] = []
        for pool in all_pools:
            apy = pool.get("apy") or 0
            tvl = pool.get("tvlUsd") or 0
            if apy <= 0 or tvl < tvl_floor:
                continue

            sym = pool.get("symbol", "").upper()
            chain = pool.get("chain", "").lower()
            project = pool.get("project", "").lower()

            if token_filter and token_filter not in sym:
                continue
            if chain_filter and chain_filter != chain:
                continue
            if protocol_filter and protocol_filter not in project:
                continue

            filtered.append(pool)

        # Sort by user-requested metric
        if sort_by == "apy":
            filtered.sort(key=lambda p: p.get("apy") or 0, reverse=True)
        else:
            filtered.sort(key=lambda p: p.get("tvlUsd") or 0, reverse=True)
        top = filtered[:5]

        if not top:
            return f"No active pools found for '{query}'. Try a different token symbol, chain, or protocol name."

        # Build universal_cards JSON with protocol URLs
        # UUID v4 pattern used by DefiLlama for internal pool IDs
        _uuid_re = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-', re.I)

        cards = []
        for p in top:
            symbol  = p.get("symbol", "—")
            chain   = p.get("chain", "").lower()
            project = p.get("project", "—")
            apy     = p.get("apy") or 0
            tvl     = p.get("tvlUsd") or 0
            pool_id = p.get("pool", "")

            # Detect if pool_id is a DefiLlama UUID vs a native on-chain address
            is_uuid = bool(_uuid_re.match(pool_id))

            # For native addresses like "0xABC-ethereum", extract the address part
            # For UUIDs, we cannot treat the DefiLlama id as a protocol-searchable pool address
            if is_uuid:
                pair_address = ""
            else:
                pair_address = pool_id.split("-")[0] if "-" in pool_id else pool_id

            defillama_url = f"https://defillama.com/yields/pool/{pool_id}" if pool_id else ""

            # Map DefiLlama chain names to DexScreener format
            chain_mapping = {
                "solana": "solana", "bsc": "bsc", "ethereum": "ethereum",
                "polygon": "polygon", "arbitrum": "arbitrum", "optimism": "optimism",
                "base": "base", "avalanche": "avalanche"
            }
            dex_chain = chain_mapping.get(chain, chain)
            dex_lower = project.lower()

            # Build protocol URL — map known protocols to their app pages
            protocol_url = ""
            if "raydium" in dex_lower:
                if pair_address:
                    protocol_url = f"https://raydium.io/liquidity/add/?ammId={pair_address}"
                else:
                    protocol_url = "https://raydium.io/liquidity/"
            elif "pancake" in dex_lower:
                protocol_url = "https://pancakeswap.finance/liquidity"
            elif "uniswap" in dex_lower:
                uni_chain = "mainnet" if chain == "ethereum" else dex_chain
                protocol_url = f"https://app.uniswap.org/explore/pools/{uni_chain}"
            elif "orca" in dex_lower:
                protocol_url = "https://www.orca.so/liquidity"
            elif "meteora" in dex_lower:
                protocol_url = "https://app.meteora.ag/"
            elif "curve" in dex_lower or "convex" in dex_lower or "ellipsis" in dex_lower:
                protocol_url = f"https://curve.fi/#/{dex_chain}/pools"
            elif "aave" in dex_lower:
                protocol_url = "https://app.aave.com/"
            elif "compound" in dex_lower:
                protocol_url = "https://app.compound.finance/"
            elif "sushi" in dex_lower:
                protocol_url = "https://www.sushi.com/pools"
            elif "balancer" in dex_lower or "beethoven" in dex_lower:
                protocol_url = f"https://app.balancer.fi/#/{dex_chain}/pools"
            elif "aerodrome" in dex_lower:
                protocol_url = "https://aerodrome.finance/pools"
            elif "velodrome" in dex_lower:
                protocol_url = "https://velodrome.finance/pools"
            elif "camelot" in dex_lower:
                protocol_url = "https://app.camelot.exchange/pools"
            elif "jito" in dex_lower:
                protocol_url = "https://www.jito.network/staking/"
            elif "marinade" in dex_lower:
                protocol_url = "https://marinade.finance/app/stake/"
            elif "lido" in dex_lower:
                protocol_url = "https://stake.lido.fi/"
            elif "jupiter" in dex_lower:
                protocol_url = "https://jup.ag/"
            elif "morpho" in dex_lower:
                protocol_url = "https://app.morpho.org/"
            elif "pendle" in dex_lower:
                protocol_url = "https://app.pendle.finance/trade/pools"
            elif "gmx" in dex_lower:
                protocol_url = "https://app.gmx.io/#/pools"
            elif "beefy" in dex_lower:
                protocol_url = "https://app.beefy.com/"
            elif "yearn" in dex_lower:
                protocol_url = f"https://yearn.fi/vaults/{dex_chain}"
            elif "save" in dex_lower:
                protocol_url = "https://app.save.org/"
            elif "drift" in dex_lower:
                protocol_url = "https://app.drift.trade/"
            elif "kamino" in dex_lower:
                protocol_url = "https://app.kamino.finance/"
            elif "marginfi" in dex_lower:
                protocol_url = "https://app.marginfi.com/"
            elif "solend" in dex_lower:
                protocol_url = "https://solend.fi/"
            elif "binance" in dex_lower:
                protocol_url = "https://www.binance.com/en/staking"
            elif pair_address:
                # Native on-chain address → DexScreener pair page
                protocol_url = f"https://dexscreener.com/{dex_chain}/{pair_address}"
            else:
                # Last resort: protocol's DexScreener page
                protocol_url = f"https://dexscreener.com/{dex_chain}"

            details_dict = {
                "APY": f"{apy:.2f}%",
                "TVL": f"${tvl:,.0f}",
            }

            if pair_address:
                details_dict["Pool Address"] = pair_address

            cards.append({
                "title": f"{symbol} Pool",
                "subtitle": f"{project.capitalize()} · {chain.capitalize()}",
                "details": details_dict,
                "url": protocol_url,
                "button_text": "View Pool",
                "defillama_url": defillama_url,
                "defillama_button_text": "View in DefiLlama",
            })

        sort_label = "highest APY" if sort_by == "apy" else "largest TVL"
        chain_label = chain_filter.capitalize() if chain_filter else "all"
        token_label = token_filter if token_filter else ""
        msg_parts = ["Here are the best liquidity pools"]
        if token_label:
            msg_parts.append(f"for {token_label}")
        msg_parts.append(f"on {chain_label}" if chain_filter else "across all chains")
        msg_parts.append(f"(sorted by {sort_label}).")
        message = " ".join(msg_parts)

        return json.dumps({
            "type": "universal_cards",
            "message": message,
            "cards": cards,
        })

    except Exception as exc:
        logger.exception("get_defi_analytics error")
        return f"DefiLlama error: {exc}"


# ---------------------------------------------------------------------------
# Step 3.6 — Solana swap via Jupiter API v6 (no platform fee, no API key)
# ---------------------------------------------------------------------------

# Well-known Solana token mint addresses for symbol resolution
_SOL_MINTS: Final[dict[str, str]] = {
    "sol":    "So11111111111111111111111111111111111111112",
    "usdc":   "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
    "usdt":   "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB",
    "bonk":   "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263",
    "wen":    "WENWENvqqNya429ubCdR81ZmD69brwQaaBYY6p3LCpk",
    "jup":    "JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN",
    "ray":    "4k3Dyjzvzp8eMZWUXbBCjEvwSkkk59S5iCNLY3QrkX6R",
    "orca":   "orcaEKTdK7LKz57vaAYr9QeNsVEPfiu6QeMU1kektZE",
    "msol":   "mSoLzYCxHdYgdzU16g5QSh3i5K3z3KZK7ytfqcJm7So",
    "jito":   "J1toso1uCk3RLmjorhTtrVwY9HJ7X8V9yYac6Y7kGCPn",
    "wbtc":   "3NZ9JMVBmGAqocybic2c7LQCJScmgsAZ6vQqTDzcqmJh",
    "weth":   "7vfCXTUXx5WJV5JADk17DUJ4ksgau7utNKj4b963voxs",
    "pyth":   "HZ1JovNiVvGrGNiiYvEozEVgZ58xaU3RKwX8eACQBCt3",
    "jto":    "jtojtomepa8b1As4vcmvBmLQMRMRMRHMDDFQPVXq4TfY",
}


def _resolve_sol_mint(token: str) -> str:
    """Return the Solana mint address for a symbol or passthrough if already a mint."""
    lower = token.strip().lower()
    if lower in _SOL_MINTS:
        return _SOL_MINTS[lower]
    # If it looks like a base58 mint address (32–44 chars, no spaces), use as-is
    if 32 <= len(token) <= 44 and token.isalnum():
        return token
    raise ValueError(f"Unknown Solana token '{token}'. Pass the mint address directly or use a known symbol.")


def build_solana_swap(raw: str) -> str:
    """
    Build a ready-to-sign Solana swap transaction via Jupiter API v6.

    Input (JSON string):
        sell_token   – mint address or symbol (e.g. "SOL", "USDC")
        buy_token    – mint address or symbol
        sell_amount  – amount to sell; may be a human-readable float (e.g. 0.5 SOL)
                       OR already in lamports (e.g. 500000000). The function converts
                       floats to the correct integer units automatically:
                         SOL / WSOL   → × 10^9
                         USDC / USDT  → × 10^6
                         everything else → × 10^9 (safe default for most SPL tokens)
        user_pubkey  – Solana wallet public key (Phantom); must not be empty

    Returns JSON with:
        status           "ok"
        chain_type       "solana"
        swapTransaction  base64-encoded serialised VersionedTransaction
        out_amount       expected output in raw units (integer)
        out_symbol       output token symbol (best-effort)
        in_symbol        input token symbol (best-effort)
    """
    try:
        params = json.loads(raw)
    except json.JSONDecodeError as exc:
        return json.dumps({"error": f"Invalid JSON input: {exc}"})

    try:
        sell_token  = str(params["sell_token"])
        buy_token   = str(params["buy_token"])
        raw_amount  = params["sell_amount"]   # may be float or int string
        user_pubkey = str(params.get("user_pubkey") or "").strip()
    except (KeyError, ValueError) as exc:
        return json.dumps({"error": f"Missing or invalid parameter: {exc}"})

    # ── Validate user_pubkey ─────────────────────────────────────────────────
    if not user_pubkey or len(user_pubkey) < 32:
        return json.dumps({
            "error": (
                "user_pubkey is missing or invalid. "
                "The Phantom wallet public key must be provided to build the transaction."
            )
        })

    # ── Resolve mint addresses ───────────────────────────────────────────────
    try:
        input_mint  = _resolve_sol_mint(sell_token)
        output_mint = _resolve_sol_mint(buy_token)
    except ValueError as exc:
        return json.dumps({"error": str(exc)})

    # ── Convert sell_amount to integer lamports ──────────────────────────────
    # Jupiter requires amount as a plain integer in the token's smallest unit.
    # The LLM might pass a human-readable float (e.g. 0.01156 SOL), so we
    # detect the token's decimals and multiply accordingly.
    _6_DECIMAL_MINTS = {
        _SOL_MINTS["usdc"],
        _SOL_MINTS["usdt"],
    }
    _9_DECIMAL_MINTS = {
        _SOL_MINTS["sol"],
        _SOL_MINTS["msol"],
        _SOL_MINTS["jito"],
    }

    try:
        amount_raw = float(raw_amount)
    except (TypeError, ValueError) as exc:
        return json.dumps({"error": f"sell_amount must be a number, got: {raw_amount!r} ({exc})"})

    if input_mint in _6_DECIMAL_MINTS:
        token_decimals = 6
    else:
        # SOL, mSOL, JitoSOL, and most SPL tokens use 9 decimals
        token_decimals = 9

    # If the value is already an integer >= 1000 it is likely already in base units
    # (e.g. the LLM passed 1000000000 for 1 SOL).  If it is a float or < 1000,
    # treat it as a human-readable amount and scale up.
    if amount_raw == int(amount_raw) and amount_raw >= 1000:
        sell_amount = int(amount_raw)
    else:
        sell_amount = int(round(amount_raw * (10 ** token_decimals)))

    if sell_amount <= 0:
        return json.dumps({"error": f"sell_amount resolved to {sell_amount} — must be > 0"})

    logger.info(
        "[Jupiter] sell %s → buy %s | raw_amount=%s decimals=%d → lamports=%d | pubkey=%s…",
        sell_token, buy_token, raw_amount, token_decimals, sell_amount, user_pubkey[:8],
    )

    jup_base = "https://public.jupiterapi.com"
    fee_account = _jupiter_fee_account()

    # ── Step 1: Quote ────────────────────────────────────────────────────────
    try:
        quote_params = {
            "inputMint":   input_mint,
            "outputMint":  output_mint,
            "amount":      sell_amount,
            "slippageBps": 50,   # 0.5 % slippage
        }
        if fee_account:
            quote_params["platformFeeBps"] = 50
        quote_resp = _requests.get(
            f"{jup_base}/quote",
            params=quote_params,
            timeout=15,
        )
        if not quote_resp.ok:
            err_text = quote_resp.text[:500]
            logger.error("[Jupiter] Quote HTTP %d: %s", quote_resp.status_code, err_text)
            return json.dumps({
                "error": f"Jupiter quote HTTP {quote_resp.status_code}: {err_text}"
            })
        quote = quote_resp.json()
    except Exception as exc:
        logger.exception("[Jupiter] Quote request failed")
        return json.dumps({"error": f"Jupiter quote request failed: {exc}"})

    if "error" in quote:
        err_msg = quote["error"]
        logger.error("[Jupiter] Quote API error: %s", err_msg)
        return json.dumps({"error": f"Jupiter quote error: {err_msg}"})

    raw_out_amount = int(quote.get("outAmount", 0))
    _SOL_MINT_ADDR = "So11111111111111111111111111111111111111112"
    out_decimals   = 9 if output_mint == _SOL_MINT_ADDR else 6
    ui_out_amount  = round(raw_out_amount / (10 ** out_decimals), 5)

    # ── Step 2: Swap transaction ─────────────────────────────────────────────
    try:
        swap_body: dict[str, Any] = {
            "quoteResponse":    quote,
            "userPublicKey":    user_pubkey,
            "wrapAndUnwrapSol": True,
        }
        if fee_account:
            swap_body["feeAccount"] = fee_account
        swap_resp = _requests.post(
            f"{jup_base}/swap",
            json=swap_body,
            timeout=20,
        )
        if not swap_resp.ok:
            err_text = swap_resp.text[:500]
            logger.error("[Jupiter] Swap HTTP %d: %s", swap_resp.status_code, err_text)
            return json.dumps({
                "error": f"Jupiter swap HTTP {swap_resp.status_code}: {err_text}"
            })
        swap_data = swap_resp.json()
    except Exception as exc:
        logger.exception("[Jupiter] Swap request failed")
        return json.dumps({"error": f"Jupiter swap request failed: {exc}"})

    if "error" in swap_data:
        err_msg = swap_data["error"]
        logger.error("[Jupiter] Swap API error: %s", err_msg)
        return json.dumps({"error": f"Jupiter swap error: {err_msg}"})

    swap_tx_b64 = swap_data.get("swapTransaction")
    if not swap_tx_b64:
        logger.error("[Jupiter] Swap response missing swapTransaction: %s", swap_data)
        return json.dumps({"error": "Jupiter returned no swapTransaction field"})

    # Best-effort human-readable symbols (reverse-lookup from mint)
    _mint_to_sym = {v: k.upper() for k, v in _SOL_MINTS.items()}
    in_sym  = _mint_to_sym.get(input_mint,  input_mint[:8] + "…")
    out_sym = _mint_to_sym.get(output_mint, output_mint[:8] + "…")

    logger.info("[Jupiter] Swap tx built OK — outAmount=%d (%s %s)", raw_out_amount, ui_out_amount, out_sym)

    return json.dumps({
        "status":          "ok",
        "type":            "solana_swap_proposal",
        "chain_type":      "solana",
        "swapTransaction": swap_tx_b64,
        "out_amount":      str(raw_out_amount),
        "ui_out_amount":   ui_out_amount,
        "in_symbol":       in_sym,
        "out_symbol":      out_sym,
    })


# ---------------------------------------------------------------------------
# Step 3.7 — Liquidity pool search via DexScreener (free, no API key)
# ---------------------------------------------------------------------------

# Normalises user/LLM chain names → DexScreener chainId strings
_DEXSCREENER_CHAIN: Final[dict[str, str]] = {
    # BNB Smart Chain
    "bsc": "bsc", "bnb": "bsc", "56": "bsc",
    "bnb chain": "bsc", "bnb smart chain": "bsc", "binance": "bsc",
    "binance smart chain": "bsc",
    # Ethereum
    "eth": "ethereum", "ethereum": "ethereum", "1": "ethereum",
    # Polygon
    "polygon": "polygon", "matic": "polygon", "137": "polygon",
    # Arbitrum
    "arbitrum": "arbitrum", "arb": "arbitrum", "42161": "arbitrum",
    # Optimism
    "optimism": "optimism", "op": "optimism", "10": "optimism",
    # Base
    "base": "base", "8453": "base",
    # Avalanche
    "avalanche": "avalanche", "avax": "avalanche", "43114": "avalanche",
    # Solana
    "solana": "solana", "sol": "solana",
    # Other
    "fantom": "fantom", "ftm": "fantom",
    "cronos": "cronos",
    "celo": "celo",
}


def find_liquidity_pool(raw: str) -> str:
    """
    Hybrid pool search: DefiLlama first (deep TVL data), DexScreener fallback (meme coins).

    Input: JSON string with keys —
        query     – token pair, e.g. "USDC USDT" or "WBNB CAKE" or "PEPE"
        chain_id  – optional: "bsc", "bnb", "56", "ethereum", "polygon", etc.

    Strategy:
        1. DefiLlama /pools — best for established/stablecoin pairs (accurate TVL).
        2. DexScreener search — fallback for new tokens / meme coins not in DefiLlama.
    """
    try:
        params   = json.loads(raw)
        query    = str(params.get("query", "")).strip()
        chain_raw = str(params.get("chain_id", "")).strip().lower()
    except (json.JSONDecodeError, AttributeError):
        query     = str(raw).strip()
        chain_raw = ""

    if not query:
        return json.dumps({"error": "query is required (e.g. 'USDC USDT' or 'WBNB CAKE')"})

    # Normalise chain to DexScreener chainId string
    chain_filter = _DEXSCREENER_CHAIN.get(chain_raw, chain_raw)

    search_tokens = [t for t in query.upper().split() if t]

    # ── Explorer URLs (shared by both paths) ─────────────────────────────────
    _EXPLORER: Final[dict[str, str]] = {
        "bsc":       "https://bscscan.com/address/{}",
        "ethereum":  "https://etherscan.io/address/{}",
        "polygon":   "https://polygonscan.com/address/{}",
        "arbitrum":  "https://arbiscan.io/address/{}",
        "optimism":  "https://optimistic.etherscan.io/address/{}",
        "base":      "https://basescan.org/address/{}",
        "avalanche": "https://snowtrace.io/address/{}",
        "solana":    "https://solscan.io/account/{}",
        "fantom":    "https://ftmscan.com/address/{}",
        "cronos":    "https://cronoscan.com/address/{}",
        "celo":      "https://celoscan.io/address/{}",
    }

    def _explorer_url(chain: str, address: str) -> str:
        tmpl = _EXPLORER.get(chain.lower(), "https://blockscan.com/address/{}")
        return tmpl.format(address) if address else ""

    # UUID v4 pattern used by DefiLlama for internal pool IDs
    _UUID_RE = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-', re.I)

    def _is_uuid(pool_id: str) -> bool:
        """True if pool_id is a DefiLlama UUID, not a native chain address."""
        return bool(_UUID_RE.match(pool_id))

    def _native_address(pool_id: str, is_uuid_pool: bool) -> str:
        """
        Strip the '-chain' suffix that DefiLlama appends to native addresses.
        e.g. '0xABC-ethereum' → '0xABC'
             'EPjFW...-solana'  → 'EPjFW...'
        UUID pool IDs are returned as-is (full UUID).
        """
        if is_uuid_pool:
            return pool_id
        return pool_id.split("-")[0]

    def _protocol_url(
        dex: str, chain: str,
        pool_id: str = "", pair_address: str = "",
        token0: str = "", token1: str = "",
    ) -> str:
        """Route to the DEX liquidity hub page for known protocols.

        Falls back to DefiLlama (pool page) for DefiLlama-sourced pools, or
        DexScreener for DexScreener-sourced pools.
        """
        d  = dex.lower()
        ch = chain.lower()
        uni_chain  = "mainnet" if ch == "ethereum" else ch
        dex_ch     = _DEXSCREENER_CHAIN.get(ch, ch)

        logger.info(
            "[protocol_url] dex=%r chain=%r pool_id=%r pair=%r tok0=%r tok1=%r",
            dex, chain, pool_id, pair_address,
            token0[:8] if token0 else "", token1[:8] if token1 else "",
        )

        # ── Known protocol hubs ────────────────────────────────────────────
        if "uniswap" in d:
            return f"https://app.uniswap.org/explore/pools/{uni_chain}"
        if "pancake" in d:
            return "https://pancakeswap.finance/liquidity"
        if "raydium" in d:
            is_uuid = "-" in pair_address
            if not is_uuid and pair_address:
                return f"https://raydium.io/liquidity/add/?ammId={pair_address}"
            return "https://raydium.io/liquidity/"
        if "orca" in d:
            return "https://www.orca.so/liquidity"
        if "meteora" in d:
            return "https://app.meteora.ag/"
        if "curve" in d or "convex" in d or "conic" in d or "ellipsis" in d:
            return f"https://curve.fi/#/{ch}/pools"
        if "aerodrome" in d:
            return "https://aerodrome.finance/pools"
        if "velodrome" in d:
            return "https://velodrome.finance/pools"
        if "camelot" in d:
            return "https://app.camelot.exchange/pools"
        if "trader" in d and "joe" in d or "lfj" in d:
            return f"https://lfj.gg/{ch}/pool"
        if "sushi" in d:
            return "https://www.sushi.com/pools"
        if "quickswap" in d:
            return "https://quickswap.exchange/#/pools"
        if "balancer" in d or "beethoven" in d:
            return f"https://app.balancer.fi/#/{ch}/pools"
        if "kyber" in d:
            return f"https://kyberswap.com/{ch}/pools"
        if "thena" in d:
            return "https://www.thena.fi/pools"
        if "fluid" in d:
            return "https://fluid.instadapp.io/liquidity"
        if "morpho" in d:
            return "https://app.morpho.org/"
        if "pendle" in d:
            return "https://app.pendle.finance/trade/pools"
        if "aave" in d:
            return "https://app.aave.com/"
        if "compound" in d:
            return "https://app.compound.finance/"
        if "spark" in d:
            return "https://app.spark.fi/"
        if "frax" in d:
            return "https://app.frax.finance/"
        if "lido" in d:
            return "https://stake.lido.fi/"
        if "gmx" in d:
            return "https://app.gmx.io/#/pools"
        if "maverick" in d:
            return f"https://app.mav.xyz/?chain={ch}"
        if "dodo" in d:
            return "https://app.dodoex.io/pools"
        if "wombat" in d:
            return "https://app.wombat.exchange/pool"
        if "yearn" in d:
            return f"https://yearn.fi/vaults/{ch}"
        if "beefy" in d:
            return "https://app.beefy.com/"

        # ── Universal fallback ─────────────────────────────────────────────
        # Avoid direct DefiLlama pool links — their frontend often returns 404.
        # DexScreener pair page for native addresses; chain hub for everything else.
        if pair_address and "-" not in pair_address:
            return f"https://dexscreener.com/{dex_ch}/{pair_address}"
        return f"https://dexscreener.com/{dex_ch}"

    def _pool_result(
        *,
        dex: str, pair_address: str, pool_symbol: str,
        base: str, quote: str,
        chain: str, liquidity: float, volume: float, apr: float,
        url: str, explorer: str, protocol_url: str = "",
        defillama_url: str = "",
    ) -> str:
        # The "url" field is what the AI uses for the "View Pool" button.
        # Always prefer protocol_url (direct link to DEX) over defillama.
        best_url = protocol_url if protocol_url else url
        result = {
            "type":           "liquidity_pool_report",
            "dexId":          dex,
            "pairAddress":    pair_address or "—",
            "poolSymbol":     pool_symbol,
            "baseToken":      base,
            "quoteToken":     quote,
            "chainId":        chain,
            "liquidity_usd":  round(liquidity, 2),
            "volume_24h_usd": round(volume, 2),
            "apr":            round(apr, 2),
            "url":            best_url,
            "explorer_url":   explorer,
            "protocol_url":   protocol_url,
            "defillama_url":  defillama_url,
        }
        logger.info(
            "[Pool] dex=%r chain=%r symbol=%r liq=$%,.0f apr=%.2f%% protocol_url=%r",
            dex, chain, pool_symbol, liquidity, apr, protocol_url,
        )
        return json.dumps(result, indent=2)

    # ── DefiLlama chain name mapping ─────────────────────────────────────────
    # Values must match DefiLlama's "chain" field exactly (case-sensitive).
    # Includes short-form aliases users might pass.
    _LLAMA_CHAIN: dict[str, str] = {
        # Ethereum
        "eth": "Ethereum", "ethereum": "Ethereum",
        # BNB / BSC
        "bsc": "BSC", "bnb": "BSC", "56": "BSC",
        # Polygon
        "polygon": "Polygon", "matic": "Polygon",
        # Others
        "arbitrum": "Arbitrum", "arb": "Arbitrum",
        "optimism": "Optimism", "op": "Optimism",
        "base": "Base",
        "avalanche": "Avalanche", "avax": "Avalanche",
        "solana": "Solana", "sol": "Solana",
        "fantom": "Fantom", "ftm": "Fantom",
        "cronos": "Cronos",
        "celo": "Celo",
    }

    # ─────────────────────────────────────────────────────────────────────────
    # Step 1 — DefiLlama (primary, best TVL accuracy)
    # ─────────────────────────────────────────────────────────────────────────
    pool_found: Optional[str] = None

    try:
        llama_resp = _requests.get("https://yields.llama.fi/pools", timeout=12)
        if llama_resp.ok:
            llama_chain = _LLAMA_CHAIN.get(chain_filter, "")
            pools = llama_resp.json().get("data") or []

            logger.info("[DefiLlama] total pools=%d llama_chain='%s' tokens=%s",
                        len(pools), llama_chain, search_tokens)

            # Filter: chain match + all tokens present in symbol.
            # Skip UUID-addressed pools with zero activity (dead trackers).
            candidates = []
            for pool in pools:
                if llama_chain and pool.get("chain", "") != llama_chain:
                    continue
                sym = pool.get("symbol", "").upper()
                # Exact token-count match: split on both '-' and '/' separators.
                # Prevents 3pool (DAI-USDC-USDT) from matching a 2-token query.
                pool_tokens = sym.replace("/", "-").split("-")
                if len(pool_tokens) != len(search_tokens):
                    continue
                if not all(any(req in pt for pt in pool_tokens) for req in search_tokens):
                    continue
                pool_id = pool.get("pool", "")
                if _is_uuid(pool_id):
                    apr_val = pool.get("apy") or 0
                    vol_val = pool.get("volumeUsd1d") or 0
                    if apr_val == 0 and vol_val == 0:
                        continue  # dead UUID tracker — no yield, no volume
                candidates.append(pool)

            logger.info("[DefiLlama] candidates after filter: %d", len(candidates))

            if candidates:
                # Assign tier-1 trust weight to well-known DEXes (guards against volume wash)
                _TIER1 = {"uniswap", "pancakeswap", "curve", "raydium", "orca",
                           "aerodrome", "camelot", "quickswap", "sushiswap", "balancer"}
                for p in candidates:
                    dex_slug = p.get("project", "").lower()
                    p["_tier1"] = 1 if any(t in dex_slug for t in _TIER1) else 0

                # Anti-scam floor: require at least $100k TVL
                legit = [p for p in candidates if float(p.get("tvlUsd") or 0) >= 100_000]
                if not legit:
                    legit = candidates  # all below floor — still show best

                # Sort: tier-1 DEXes first, then by TVL within each tier
                legit.sort(key=lambda p: (p.get("_tier1", 0), float(p.get("tvlUsd") or 0)), reverse=True)
                best = legit[0]

                # pool field: "0xABC-ethereum", "EPjFW...-solana", or UUID
                raw_pool_id  = best.get("pool", "")
                is_uuid_pool = _is_uuid(raw_pool_id)
                pair_address = _native_address(raw_pool_id, is_uuid_pool)

                pool_sym  = best.get("symbol", "")
                parts     = pool_sym.split("-")
                base_tok  = parts[0].upper() if parts else pool_sym
                quote_tok = "-".join(p.upper() for p in parts[1:]) if len(parts) >= 2 else "—"

                chain_out = chain_filter or best.get("chain", "").lower()
                dex_name  = best.get("project", "—")

                underlying = best.get("underlyingTokens") or []
                tok0 = underlying[0] if len(underlying) > 0 else ""
                tok1 = underlying[1] if len(underlying) > 1 else ""

                dex_chain_id = _DEXSCREENER_CHAIN.get(chain_out, chain_out)
                if not is_uuid_pool and pair_address:
                    explorer = _explorer_url(chain_out, pair_address)
                else:
                    explorer = ""

                # url = прямая ссылка на конкретный пул в DefiLlama (желтая кнопка)
                defillama_pool_url = (
                    f"https://defillama.com/yields/pool/{raw_pool_id}"
                    if raw_pool_id else "https://defillama.com/yields"
                )

                pool_found = _pool_result(
                    dex=dex_name,
                    pair_address=pair_address,
                    pool_symbol=pool_sym,
                    base=base_tok,
                    quote=quote_tok,
                    chain=chain_out,
                    liquidity=float(best.get("tvlUsd") or 0),
                    volume=float(best.get("volumeUsd1d") or 0),
                    apr=float(best.get("apy") or 0),
                    url=defillama_pool_url,
                    explorer=explorer,
                    defillama_url=defillama_pool_url,
                    protocol_url=_protocol_url(
                        dex_name, chain_out,
                        pool_id=raw_pool_id,
                        pair_address=pair_address,
                        token0=tok0,
                        token1=tok1,
                    ),
                )
        if not pool_found:
            logger.info("[DefiLlama] No matching pools — falling back to DexScreener")
    except Exception as llama_exc:
        logger.warning("[DefiLlama] Error (%s) — falling back to DexScreener", llama_exc)

    # ─────────────────────────────────────────────────────────────────────────
    # Step 2 — DexScreener fallback (meme coins, new tokens)
    # ─────────────────────────────────────────────────────────────────────────
    if not pool_found:
        if len(search_tokens) >= 2:
            anchor_query = f"{search_tokens[0]}/{search_tokens[1]}"
        else:
            anchor_query = search_tokens[0]
        api_query = f"{anchor_query} {chain_filter}" if chain_filter else anchor_query

        logger.info("[DexScreener] query='%s' tokens=%s", api_query, search_tokens)

        try:
            dex_resp = _requests.get(
                "https://api.dexscreener.com/latest/dex/search",
                params={"q": api_query},
                timeout=10,
            )
            if not dex_resp.ok:
                err = dex_resp.text[:300]
                logger.error("[DexScreener] HTTP %d: %s", dex_resp.status_code, err)
            else:
                pairs = dex_resp.json().get("pairs") or []

                # Chain filter
                if chain_filter:
                    pairs = [p for p in pairs if p.get("chainId", "").lower() == chain_filter]

                # Token match filter (substring, handles USDC.e / WBNB variants)
                valid: list = []
                for p in pairs:
                    base_sym  = p.get("baseToken",  {}).get("symbol", "").upper()
                    quote_sym = p.get("quoteToken", {}).get("symbol", "").upper()
                    if all(tok in f"{base_sym} {quote_sym}" for tok in search_tokens):
                        valid.append(p)

                # Sort by liquidity
                valid.sort(key=lambda p: float((p.get("liquidity") or {}).get("usd") or 0), reverse=True)

                logger.info("[DexScreener] valid pairs after filter: %d", len(valid))

                if valid:
                    p            = valid[0]
                    chain_out    = p.get("chainId", chain_filter or "—").lower()
                    pair_address = p.get("pairAddress", "")
                    dex_id       = p.get("dexId", "—")
                    base_sym     = p.get("baseToken",  {}).get("symbol", "—")
                    quote_sym    = p.get("quoteToken", {}).get("symbol", "—")
                    pool_found   = _pool_result(
                        dex=dex_id,
                        pair_address=pair_address,
                        pool_symbol=f"{base_sym}-{quote_sym}",
                        base=base_sym,
                        quote=quote_sym,
                        chain=chain_out,
                        liquidity=float((p.get("liquidity") or {}).get("usd") or 0),
                        volume=float((p.get("volume") or {}).get("h24") or 0),
                        apr=0.0,
                        url=p.get("url", ""),
                        explorer=_explorer_url(chain_out, pair_address),
                        protocol_url=_protocol_url(
                            dex_id, chain_out,
                            pair_address=pair_address,
                        ),
                    )
        except Exception as exc:
            logger.exception("[DexScreener] Request failed: %s", exc)

    # ── Final result ─────────────────────────────────────────────────────────
    if pool_found:
        return pool_found

    chain_note = f" on '{chain_filter}'" if chain_filter else ""
    return json.dumps({"error": f"No matching pools found for '{query}'{chain_note}"})


# ---------------------------------------------------------------------------
# Step 3.8 — Universal DexScreener pair search (contract address / token name)
# ---------------------------------------------------------------------------

def search_dexscreener_pairs(query: str) -> str:
    """
    Universal market radar via DexScreener API.

    Input: token contract address (any chain) OR token name/symbol.
    Returns: top-3 trading pairs ranked by 24h volume, with DEX, price, liquidity, and link.
    """
    query = query.strip()
    if not query:
        return "Error: query is required (contract address or token name)."

    # Smart endpoint routing: contract addresses use /tokens/, text search uses /search
    if query.startswith("0x") or len(query) > 30:
        endpoint = f"https://api.dexscreener.com/latest/dex/tokens/{query}"
    else:
        endpoint = f"https://api.dexscreener.com/latest/dex/search?q={query}"

    try:
        resp = _requests.get(endpoint, timeout=10)
        resp.raise_for_status()
        pairs = resp.json().get("pairs") or []
    except Exception as exc:
        logger.exception("[DexScreener Search] Request failed: %s", exc)
        return f"Error fetching DexScreener data: {exc}"

    if not pairs:
        return f"No trading pairs found for '{query}' on DexScreener."

    # Sort by 24h volume descending, take top-3
    pairs.sort(key=lambda p: float((p.get("volume") or {}).get("h24") or 0), reverse=True)
    top = pairs[:3]

    def _trade_url(dex_id: str, token_address: str, fallback: str) -> str:
        d = dex_id.lower()
        if "raydium" in d:
            return f"https://raydium.io/swap/?outputMint={token_address}"
        if "pump" in d:
            return f"https://pump.fun/{token_address}"
        if "uniswap" in d:
            return f"https://app.uniswap.org/swap?outputCurrency={token_address}"
        if "pancakeswap" in d:
            return f"https://pancakeswap.finance/swap?outputCurrency={token_address}"
        if "meteora" in d:
            return "https://app.meteora.ag/"
        if "orca" in d:
            return "https://www.orca.so/"
        return fallback

    cards = []
    for p in top:
        dex_id       = p.get("dexId", "")
        chain        = p.get("chainId", "")
        base_token   = p.get("baseToken") or {}
        quote_token  = p.get("quoteToken") or {}
        base_sym     = base_token.get("symbol", "?")
        quote_sym    = quote_token.get("symbol", "?")
        base_addr    = base_token.get("address", "")
        ds_url       = p.get("url", "")
        try:
            price_str = f"${float(p.get('priceUsd') or 0):.6f}"
        except (ValueError, TypeError):
            price_str = "N/A"
        liq = float((p.get("liquidity") or {}).get("usd") or 0)
        vol = float((p.get("volume") or {}).get("h24") or 0)

        cards.append({
            "title":       f"{base_sym}/{quote_sym}",
            "subtitle":    f"{dex_id.capitalize()} · {chain.upper()}",
            "details":     {
                "Price":      price_str,
                "Liquidity":  f"${liq:,.0f}",
                "Volume 24h": f"${vol:,.0f}",
            },
            "url":         _trade_url(dex_id, base_addr, ds_url),
            "button_text": "Trade Now",
        })

    return json.dumps({
        "type":    "universal_cards",
        "message": f"🔍 Top {len(cards)} trading pair(s) for **{query}**:",
        "cards":   cards,
    })


# ---------------------------------------------------------------------------
# Step 4 — Agent factory
# ---------------------------------------------------------------------------

def build_agent(
    session_id: str,
    user_address: str,
    chain_id: int,
    openrouter_model: Optional[str] = None,
    solana_address: str = "",
) -> AgentExecutor:
    """
    Returns a ZERO_SHOT_REACT_DESCRIPTION AgentExecutor bound to `session_id`.

    The agent's system prompt injects {chat_history} from ConversationBufferMemory,
    giving the LLM context across turns within the same session.
    """
    llm = _build_llm(openrouter_model)
    memory = _get_or_create_memory(session_id)

    tools = [
        Tool(
            name="get_wallet_balance",
            func=lambda addr: get_smart_wallet_balance(addr, user_address, solana_address),
            description=(
                "Returns native coin and stablecoin (USDC, USDT) balances. "
                "Automatically detects Solana (base58, no 0x) vs EVM (0x) addresses. "
                "EVM chains are scanned concurrently across 15 networks. "
                "Input format: 'address' for all chains, or 'address|chain' to filter. "
                "Supported chain keywords: eth, bnb, polygon, arbitrum, optimism, base, "
                "avalanche, zksync, linea, scroll, mantle, fantom, gnosis, celo, cronos, solana."
            ),
        ),
        Tool(
            name="simulate_swap",
            func=lambda raw: _simulate_swap(raw, chain_id),
            description=(
                "Estimates the token output of a swap using the 1inch Aggregation API. "
                "Input must be exactly three space-separated values: "
                "TOKEN_IN_ADDRESS TOKEN_OUT_ADDRESS AMOUNT_IN_WEI  "
                "Example: 0xbb4CdB9C... 0x55d39832... 1000000000000000000"
            ),
        ),
        Tool(
            name="get_token_price",
            func=_get_token_price,
            description=(
                "Returns the current USD price of a token. "
                "Input: a symbol like 'BNB', 'BTC', 'ETH', 'USDT' "
                "or a CoinGecko coin ID like 'binancecoin', 'bitcoin'."
            ),
        ),
        Tool(
            name="build_swap_tx",
            func=lambda raw: _build_swap_tx(raw, user_address, chain_id),
            description=(
                "Builds a complete, ready-to-sign swap transaction including platform "
                "referral fees. Returns a JSON object the extension sends to the wallet "
                "for signing. "
                "Input: a JSON string with these keys — "
                "chain (evm or solana), "
                "token_in (address/mint), "
                "token_out (address/mint), "
                "amount (in wei for EVM, base units for Solana), "
                "from (sender wallet address; omit to use the user's address), "
                "chain_id (EVM only; omit to use session chain), "
                "slippage_bps (optional, default 100 for EVM / 50 for Solana). "
                "Example EVM: "
                "{{\"chain\":\"evm\",\"token_in\":\"0xbb4C...\",\"token_out\":\"0x55d3...\","
                "\"amount\":\"1000000000000000000\",\"chain_id\":56}}. "
                "Example Solana: "
                "{{\"chain\":\"solana\",\"token_in\":\"So11...SOL\","
                "\"token_out\":\"EPjFW...USDC\",\"amount\":\"1000000000\","
                "\"from\":\"YourSolanaPubkey\"}}."
            ),
        ),
        Tool(
            name="get_defi_market_overview",
            func=get_defi_market_overview,
            description=(
                "Returns a live macro overview of the DeFi market: total TVL, top-10 blockchains "
                "by TVL, dominance breakdown. Use this for ANY general question about the DeFi "
                "market state, trends, sentiment, or outlook — e.g. 'what do you think about DeFi', "
                "'how is the DeFi market', 'DeFi trends', 'which chain is leading'. "
                "No input needed — pass an empty string."
            ),
        ),
        Tool(
            name="get_defi_analytics",
            func=get_defi_analytics,
            description=(
                "Fetches live DeFi yield data from DefiLlama (no API key needed). "
                "Use this tool whenever the user asks about: earning yield, APY, APR, staking, "
                "best pools, TVL of a protocol, passive income, 'where to stake X', "
                "'best pools on Y chain', or any question about DeFi strategies. "
                "Input: a query string combining token symbol, chain name, and/or protocol. "
                "Append 'sort:apy' to sort by highest APY instead of default TVL. "
                "IMPORTANT: when the user asks for 'highest APR', 'highest APY', 'best yield', "
                "'top APY', or 'highest return', you MUST add 'sort:apy' to the input. "
                "Examples: 'USDC polygon' (by TVL), 'SOL solana sort:apy' (by APY), "
                "'solana sort:apy' (highest APY on Solana, any token). "
                "Note: DefiLlama provides APY (compound), not APR (simple)."
            ),
        ),
        Tool(
            name="search_dexscreener_pairs",
            func=search_dexscreener_pairs,
            description=(
                "Universal token/pair search via DexScreener. "
                "Use this tool when the user provides a CONTRACT ADDRESS (any chain, including Solana) "
                "or asks 'where to trade this token', 'find pairs for <address>', "
                "'is this token listed anywhere', or pastes a raw mint/contract address. "
                "Also use for meme coins and newly launched tokens not found in DefiLlama. "
                "Input: the contract address OR token symbol/name as a plain string. "
                "Returns top-3 pairs ranked by 24h volume with DEX name, chain, price, liquidity, and link."
            ),
        ),
        Tool(
            name="find_liquidity_pool",
            func=find_liquidity_pool,
            description=(
                "Searches DexScreener for liquidity pools by token pair. "
                "Use this tool WHENEVER the user asks for a liquidity pool address, "
                "pair address, pool contract, or wants to know where a token pair trades. "
                "Input: a JSON string with keys — "
                "query (required, token pair e.g. 'USDC USDT' or 'WBNB CAKE'), "
                "chain_id (optional filter: 'bsc', 'ethereum', 'solana', 'polygon', etc.). "
                "Example: {{\"query\":\"USDC USDT\",\"chain_id\":\"bsc\"}}. "
                "Returns top-3 pools sorted by liquidity with dexId, pairAddress, "
                "token symbols, liquidity_usd, and volume_24h_usd."
            ),
        ),
        Tool(
            name="build_solana_swap",
            func=lambda raw: build_solana_swap(raw),
            description=(
                "Builds a ready-to-sign Solana swap transaction using Jupiter API v6 (no fees). "
                "Use this tool WHENEVER the user wants to swap tokens and a Solana/Phantom wallet is connected. "
                "Input: a JSON string with keys — "
                "sell_token (mint address or symbol: 'SOL', 'USDC', 'BONK', etc.), "
                "buy_token (mint address or symbol), "
                "sell_amount (integer in smallest units: 1 SOL = 1000000000, 1 USDC = 1000000), "
                "user_pubkey (the user's Solana wallet public key). "
                "Example: {{\"sell_token\":\"SOL\",\"buy_token\":\"USDC\","
                "\"sell_amount\":500000000,\"user_pubkey\":\"<phantom_pubkey>\"}}. "
                "Returns a JSON with swapTransaction (base64) that the frontend sends to Phantom for signing. "
                "Always show the user the expected out_amount and out_symbol before they sign."
            ),
        ),
        Tool(
            name="build_transfer_tx",
            func=lambda raw: _build_transfer_transaction(raw, chain_id),
            description=(
                "Builds a ready-to-sign token transfer transaction (send / transfer / отправить). "
                "Use this IMMEDIATELY when the user wants to send or transfer crypto. "
                "Returns a JSON object with type='transaction' for MetaMask signing. "
                "IMPORTANT: For non-ETH native coins, always include chain_id in the JSON: "
                "AVAX → chain_id 43114, BNB → 56, MATIC → 137, FTM → 250, "
                "MNT → 5000, xDAI → 100, CELO → 42220, CRO → 25. "
                "Input: a JSON string with these keys — "
                "token_symbol (required, e.g. 'AVAX', 'BNB', 'USDT'), "
                "amount (required, float), "
                "to_address (required, recipient 0x… address), "
                "chain_id (required for non-ETH natives, e.g. 43114 for AVAX), "
                "token_address (optional — only for unknown tokens). "
                "Example AVAX: {{\"token_symbol\":\"AVAX\",\"amount\":1.0,\"to_address\":\"0xABC…\",\"chain_id\":43114}}. "
                "Example BNB: {{\"token_symbol\":\"BNB\",\"amount\":0.1,\"to_address\":\"0xABC…\",\"chain_id\":56}}. "
                "Example USDT on ETH: {{\"token_symbol\":\"USDT\",\"amount\":50,\"to_address\":\"0xABC…\"}}."
            ),
        ),
    ]

    agent: AgentExecutor = initialize_agent(
        tools=tools,
        llm=llm,
        agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
        memory=memory,
        verbose=True,
        handle_parsing_errors=True,
        max_iterations=5,
        early_stopping_method="generate",  # ask LLM for a real answer if limit hit
        # Inject system prompt + {chat_history} into ZeroShotAgent's prefix
        agent_kwargs={
            "prefix": _build_system_prompt(chain_id, user_address, solana_address),
            "input_variables": ["input", "chat_history", "agent_scratchpad"],
        },
    )
    return agent
