from typing import Optional
from pydantic import BaseModel, Field


class AgentRequest(BaseModel):
    user_address: str = Field(..., description="EVM-compatible wallet address of the caller")
    solana_address: Optional[str] = Field(None, description="Solana wallet address (Phantom)")
    query: str = Field(..., description="Natural-language question or command for the agent")
    chain_id: int = Field(..., description="EIP-155 chain ID (e.g. 1 = Ethereum, 137 = Polygon)")
    session_id: str = Field(..., description="Unique session identifier for conversation continuity")
    chat_id: Optional[str] = Field(None, description="Existing chat ID to continue (null = new chat)")
