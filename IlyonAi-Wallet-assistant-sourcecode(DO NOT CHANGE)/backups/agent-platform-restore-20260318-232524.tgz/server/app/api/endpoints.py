import asyncio
import re
import time
import uuid
from datetime import datetime
from typing import Any, List, Optional

from pydantic import BaseModel

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from app.schemas.request import AgentRequest
from app.core.config import settings
from app.db.database import get_db
from app.db.models import Chat, ChatMessage, User
from app.api.auth import get_optional_user

router = APIRouter()
_oauth2 = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login", auto_error=False)


def _clean_agent_output(text: str) -> str:
    """
    Strip leaked ReAct scaffolding from the agent's final output.

    LangChain's ZERO_SHOT_REACT agent sometimes leaks its internal trace when
    the LLM doesn't follow the exact ReAct format — e.g. it outputs:
        Question: Hello
        Thought: ...
        Action: None
    instead of a clean Final Answer.  We detect this and extract the useful part.
    """
    if not text:
        return text

    # 1. If the text starts with "Question:" or "Thought:", it's leaked ReAct format.
    if re.match(r"^(Question|Thought|Action|Observation):", text.strip()):
        # First priority: extract a proper Final Answer if one is embedded
        final_match = re.search(r"Final Answer:\s*(.+)", text, re.DOTALL)
        if final_match:
            return final_match.group(1).strip()

        # Second priority: a Thought that reads like a real answer (not meta-commentary)
        thought_match = re.search(
            r"Thought:\s*(.+?)(?=\n(?:Action|Observation|Final Answer|Question):|$)",
            text, re.DOTALL
        )
        if thought_match:
            thought = thought_match.group(1).strip()
            skip_phrases = ("i need to", "i should call", "i must use", "i will use", "let me check")
            if len(thought) > 20 and not any(thought.lower().startswith(p) for p in skip_phrases):
                return thought

        # Last resort: strip all ReAct labels AND the Question line entirely
        cleaned = re.sub(r"^Question:.*$", "", text, flags=re.MULTILINE)
        cleaned = re.sub(
            r"(Thought|Action Input|Action|Observation|Final Answer):\s*",
            "", cleaned
        ).strip()
        cleaned = re.sub(r"\bNone\b\s*", "", cleaned).strip()
        cleaned = re.sub(r"\n{3,}", "\n\n", cleaned).strip()
        if cleaned:
            return cleaned

    return text

# ── Simple per-key rate limiter ───────────────────────────────────────────────
# Stores last request timestamp per user_id (or IP for anonymous users).
# Minimum gap between requests: 3 seconds.
_last_request: dict[str, float] = {}
_MIN_GAP = 3.0  # seconds


def _check_rate_limit(key: str) -> None:
    now = time.monotonic()
    last = _last_request.get(key, 0.0)
    if now - last < _MIN_GAP:
        wait = round(_MIN_GAP - (now - last), 1)
        raise HTTPException(status_code=429, detail=f"Too many requests. Please wait {wait}s.")
    _last_request[key] = now


def _auto_title(text: str) -> str:
    """Generate a chat title from the first user message (max 40 chars)."""
    clean = text.strip().replace("\n", " ")
    return clean[:40] + ("…" if len(clean) > 40 else "")


@router.post("/agent")
async def run_agent(
    request: Request,
    body: AgentRequest,
    current_user: Optional[User] = Depends(get_optional_user),
    db: Session = Depends(get_db),
) -> dict:
    # Rate limit: 1 request per 3 seconds per user (or per IP for anonymous)
    rate_key = str(current_user.id) if current_user else (request.client.host if request.client else "anon")
    _check_rate_limit(rate_key)

    from app.agents.crypto_agent import build_agent, _OPENROUTER_MODELS  # imported lazily to avoid import-time errors

    # ── Determine session identity (no DB write yet — avoids orphan chats on error) ──
    provided_chat_id: Optional[str] = getattr(body, "chat_id", None)

    if current_user and provided_chat_id:
        existing = db.query(Chat).filter(Chat.id == provided_chat_id, Chat.user_id == current_user.id).first()
        effective_session_id = provided_chat_id if existing else str(uuid.uuid4())
    elif current_user:
        effective_session_id = str(uuid.uuid4())
    else:
        effective_session_id = body.session_id

    # ── Build ordered list of models/providers to try ────────────────────────
    # "__groq__" is a sentinel that tells _build_llm to skip OpenRouter and use Groq
    models_to_try: list[Optional[str]] = []
    # OpenAI direct — most reliable for ReAct tool use
    if settings.api_keys.get("openai"):
        models_to_try.append("__openai__")
    if settings.api_keys.get("openrouter"):
        models_to_try.extend(_OPENROUTER_MODELS)
    if settings.api_keys.get("groq"):
        models_to_try.append("__groq__")
    if not models_to_try:
        raise HTTPException(status_code=503, detail="No LLM API key configured. Add openrouter, groq, or openai to API_KEYS in server/.env.")

    # ── Run the agent ────────────────────────────────────────────────────────
    last_exc: Optional[Exception] = None

    for model in models_to_try:
        agent = build_agent(
            session_id=effective_session_id,
            user_address=body.user_address,
            solana_address=body.solana_address or "",
            chain_id=body.chain_id,
            openrouter_model=model,
        )
        try:
            result = await asyncio.wait_for(
                agent.ainvoke({"input": body.query}),
                timeout=55.0,
            )
            response_text = _clean_agent_output(result.get("output", ""))

            # ── Save messages to DB only after a successful response ─────────
            # This prevents orphan empty chats when the agent fails (e.g. 429).
            chat: Optional[Chat] = None
            if current_user:
                if provided_chat_id:
                    chat = db.query(Chat).filter(Chat.id == provided_chat_id, Chat.user_id == current_user.id).first()
                if not chat:
                    chat = Chat(
                        id=effective_session_id,
                        user_id=current_user.id,
                        title=_auto_title(body.query),
                    )
                    db.add(chat)
                    db.flush()
                db.add(ChatMessage(chat_id=chat.id, role="user", content=body.query))
                db.add(ChatMessage(chat_id=chat.id, role="assistant", content=response_text))
                chat.updated_at = datetime.utcnow()
                if chat.title == "New Chat":
                    chat.title = _auto_title(body.query)
                db.commit()

            return {
                "session_id": effective_session_id,
                "chat_id": chat.id if chat else None,
                "response": response_text,
            }
        except (asyncio.TimeoutError, TimeoutError):
            raise HTTPException(status_code=504, detail="The AI agent took too long to respond. Please try a simpler question.")
        except Exception as exc:
            err_str = str(exc)
            if "429" in err_str or "rate" in err_str.lower() or "timed out" in err_str.lower():
                last_exc = exc
                continue  # try next model
            if "401" in err_str or "user not found" in err_str.lower() or "unauthorized" in err_str.lower():
                raise HTTPException(
                    status_code=401,
                    detail="Invalid AI provider API key. Please update API_KEYS in server/.env and restart the server.",
                ) from exc
            # LLM responded in plain text instead of ReAct format — extract and return the text
            if (
                "could not parse llm output" in err_str.lower()
                or "invalid format" in err_str.lower()
                or "output parsing" in err_str.lower()
                or "missing 'action'" in err_str.lower()
            ):
                import re as _re
                match = _re.search(r"Could not parse LLM output:\s*`(.*)`", err_str, _re.S)
                llm_text = _clean_agent_output(match.group(1).strip() if match else err_str)
                # Save to DB even for parse-error recoveries
                recovered_chat: Optional[Chat] = None
                if current_user:
                    try:
                        if provided_chat_id:
                            recovered_chat = db.query(Chat).filter(Chat.id == provided_chat_id, Chat.user_id == current_user.id).first()
                        if not recovered_chat:
                            recovered_chat = Chat(
                                id=effective_session_id,
                                user_id=current_user.id,
                                title=_auto_title(body.query),
                            )
                            db.add(recovered_chat)
                            db.flush()
                        db.add(ChatMessage(chat_id=recovered_chat.id, role="user", content=body.query))
                        db.add(ChatMessage(chat_id=recovered_chat.id, role="assistant", content=llm_text))
                        recovered_chat.updated_at = datetime.utcnow()
                        db.commit()
                    except Exception:
                        db.rollback()
                return {
                    "session_id": effective_session_id,
                    "chat_id": recovered_chat.id if recovered_chat else None,
                    "response": llm_text,
                }
            raise HTTPException(status_code=500, detail=err_str) from exc

    raise HTTPException(
        status_code=429,
        detail="All AI providers are currently rate-limited. Please wait a moment and try again.",
    )


class RpcRequest(BaseModel):
    rpc_url: str
    method: str
    params: List[Any]


@router.post("/rpc-proxy")
async def rpc_proxy(req: RpcRequest):
    """Proxy for cross-chain RPC calls to bypass browser CORS."""
    import httpx
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                req.rpc_url,
                json={"jsonrpc": "2.0", "id": 1, "method": req.method, "params": req.params},
                timeout=10.0,
            )
            return {"result": resp.json().get("result", "0x0")}
    except Exception as e:
        return {"result": "0x0", "error": str(e)}
