import os
import time
from datetime import datetime, timedelta
from typing import Optional

import bcrypt as _bcrypt
from jose import JWTError, jwt

JWT_SECRET = os.environ.get("JWT_SECRET", "dev-secret-change-in-production-use-random-64-char-hex")
JWT_ALGORITHM = "HS256"
JWT_EXPIRE_DAYS = 30


def create_token(user_id: int) -> str:
    expire = datetime.utcnow() + timedelta(days=JWT_EXPIRE_DAYS)
    payload = {"sub": str(user_id), "exp": expire}
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def decode_token(token: str) -> int:
    """Returns user_id or raises JWTError."""
    payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
    sub = payload.get("sub")
    if sub is None:
        raise JWTError("Invalid token payload")
    return int(sub)


def hash_password(plain: str) -> str:
    return _bcrypt.hashpw(plain.encode("utf-8"), _bcrypt.gensalt()).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    return _bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))


def verify_metamask(address: str, message: str, signature: str) -> bool:
    """
    Verify a MetaMask personal_sign signature.
    The message must contain a Unix timestamp within 5 minutes of now.
    """
    import logging
    _log = logging.getLogger(__name__)
    try:
        from web3 import Web3
        from eth_account.messages import encode_defunct

        # Extract timestamp from message: "Sign in to Agent Platform\n\nTimestamp: {unix_ts}"
        ts_line = [line for line in message.split("\n") if line.startswith("Timestamp:")]
        if not ts_line:
            _log.warning("verify_metamask: no Timestamp line in message: %r", message)
            return False
        ts = int(ts_line[0].split(":")[1].strip())
        if abs(time.time() - ts) > 300:
            _log.warning("verify_metamask: timestamp expired (diff=%.0fs)", abs(time.time() - ts))
            return False

        w3 = Web3()
        msg = encode_defunct(text=message)
        recovered = w3.eth.account.recover_message(msg, signature=signature)
        _log.info("verify_metamask: recovered=%s expected=%s", recovered.lower(), address.lower())
        return recovered.lower() == address.lower()
    except Exception as e:
        _log.warning("verify_metamask exception: %s", e)
        return False


def _b58decode(s: str) -> bytes:
    alphabet = b"123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    n = 0
    for char in s.encode("ascii"):
        n = n * 58 + alphabet.index(char)
    result = []
    while n:
        result.append(n & 0xFF)
        n >>= 8
    leading = len(s) - len(s.lstrip("1"))
    return bytes([0] * leading + result[::-1])


def verify_phantom(public_key_b58: str, message: str, signature_b58: str) -> bool:
    """Verify a Phantom signMessage ed25519 signature."""
    import logging
    _log = logging.getLogger(__name__)
    try:
        import nacl.signing
        import nacl.exceptions

        pub_bytes = _b58decode(public_key_b58)
        try:
            sig_bytes = _b58decode(signature_b58)
        except Exception:
            sig_bytes = bytes.fromhex(signature_b58)

        msg_bytes = message.encode("utf-8")
        verify_key = nacl.signing.VerifyKey(pub_bytes)
        verify_key.verify(msg_bytes, sig_bytes)
        return True
    except nacl.exceptions.BadSignatureError:
        _log.warning("verify_phantom: bad signature for key=%s", public_key_b58)
        return False
    except Exception as e:
        _log.warning("verify_phantom exception: %s", e)
        return False
