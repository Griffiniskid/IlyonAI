/**
 * Phantom wallet connection — Solana primary, EVM secondary.
 * Fetches both addresses and combines them as "solAddr,evmAddr".
 * The combined string is stored in localStorage and passed to the backend.
 */

type EthProvider = { request: (a: { method: string; params?: unknown[] }) => Promise<unknown>; isPhantom?: boolean };
type PhantomWindow = { phantom?: { solana?: { connect: () => Promise<{ publicKey: { toString: () => string } }>; disconnect: () => void; signMessage: (msg: Uint8Array, encoding: string) => Promise<{ signature: Uint8Array }> }; ethereum?: EthProvider }; ethereum?: EthProvider };

export interface PhantomSession {
  solanaAddress: string;
  evmAddress: string;      // empty string if unavailable
  combinedAddress: string; // "solAddr,evmAddr" or just "solAddr"
  displayName: string;     // based on Solana address only
  // for backend authentication
  signedMessage: string;   // the message that was signed
  signature: string;       // base58 signature
}

function _uint8ToBase58(bytes: Uint8Array): string {
  const ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
  let num = BigInt(0);
  for (const byte of bytes) {
    num = num * BigInt(256) + BigInt(byte);
  }
  let encoded = "";
  while (num > BigInt(0)) {
    const rem = Number(num % BigInt(58));
    num = num / BigInt(58);
    encoded = ALPHABET[rem] + encoded;
  }
  // Leading zeros
  for (const byte of bytes) {
    if (byte === 0) encoded = "1" + encoded;
    else break;
  }
  return encoded;
}

export async function connectPhantomSolana(): Promise<PhantomSession> {
  const w = window as unknown as PhantomWindow;

  if (!w.phantom) {
    throw new Error("Phantom not installed. Please install it from phantom.app");
  }
  if (!w.phantom.solana) {
    throw new Error("Phantom Solana wallet not available. Please open Phantom and enable the Solana wallet.");
  }

  // 1. Solana address
  const resp = await w.phantom.solana.connect();
  const solanaAddress = resp.publicKey.toString();

  // 2. EVM address — strictly from window.phantom.ethereum, never window.ethereum
  //    (avoids hijacking MetaMask's provider when both wallets are installed)
  let evmAddress = "";
  if (w.phantom.ethereum) {
    try {
      const accounts = await w.phantom.ethereum.request({ method: "eth_requestAccounts" }) as string[];
      evmAddress = accounts[0] ?? "";
    } catch (e) {
      console.warn("Could not get EVM address from Phantom:", e);
    }
  }

  // 3. Combined address — sent to backend for dual-chain scanning
  const combinedAddress = evmAddress ? `${solanaAddress},${evmAddress}` : solanaAddress;

  // 4. Sign a timestamped message for backend authentication
  const signedMessage = `Sign in to Agent Platform\n\nTimestamp: ${Math.floor(Date.now() / 1000)}`;
  let signature = "";
  try {
    const encodedMsg = new TextEncoder().encode(signedMessage);
    const signResult = await w.phantom.solana.signMessage(encodedMsg, "utf8");
    signature = _uint8ToBase58(signResult.signature);
  } catch (e) {
    console.warn("Could not get signature from Phantom:", e);
  }

  // Persist
  localStorage.setItem("ap_sol_wallet", combinedAddress);
  localStorage.setItem("ap_wallet_type", "phantom");
  localStorage.removeItem("ap_wallet");
  localStorage.removeItem("ap_token");

  return {
    solanaAddress,
    evmAddress,
    combinedAddress,
    displayName: `${solanaAddress.slice(0, 6)}…${solanaAddress.slice(-4)}`,
    signedMessage,
    signature,
  };
}

export function disconnectPhantomSolana(): void {
  try {
    (window as unknown as PhantomWindow).phantom?.solana?.disconnect();
  } catch (_) {
    // ignore
  }
}
